// WeekStrip — Material 3 Expressive week calendar for the Plan screen
function WeekStrip({ selectedDate, onSelect, variant = 'default' }) {
  const [weekOffset, setWeekOffset] = React.useState(0);
  const today = PLAN_DATA.today;
  const days = React.useMemo(() => buildWeekStrip(today, weekOffset), [weekOffset]);

  const goPrev = () => setWeekOffset(w => w - 1);
  const goNext = () => setWeekOffset(w => w + 1);

  const headerDate = days[3]; // Thursday
  const label = monthName(headerDate);

  return (
    <div style={{ fontFamily: HRT_FONT }}>
      {/* month header */}
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '4px 8px 0px', gap: 4,
      }}>
        <IconButton icon="chevron_left" onClick={goPrev} />
        <div style={{
          flex: 1, textAlign: 'center',
          fontSize: 16, fontWeight: 500,
          letterSpacing: 0.15, color: HRT.onSurface,
        }}>{label}</div>
        <IconButton icon="chevron_right" onClick={goNext} />
      </div>

      {/* week strip */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)',
        padding: '8px 4px 12px', gap: 2,
      }}>
        {days.map((d, i) => {
          const isToday = isSameDay(d, today);
          const isSelected = isSameDay(d, selectedDate);
          const dayNum = d.getDate();
          const sameMonth = d.getMonth() === today.getMonth();
          const status = sameMonth ? PLAN_DATA.status(dayNum) : 'none';
          return (
            <DayCell
              key={i}
              day={d}
              isToday={isToday}
              isSelected={isSelected}
              status={status}
              onClick={() => onSelect(d)}
              variant={variant}
            />
          );
        })}
      </div>
    </div>
  );
}

function DayCell({ day, isToday, isSelected, status, onClick, variant }) {
  const isPast = day < PLAN_DATA.today && !isSameDay(day, PLAN_DATA.today);
  const dowLabel = dowShort(day);
  const dayNum = day.getDate();

  // selected: filled primary pill. today: outlined. otherwise: transparent
  const bg = isSelected ? HRT.primary : 'transparent';
  const fg = isSelected ? HRT.onPrimary : (isToday ? HRT.primary : HRT.onSurface);
  const dowColor = isSelected ? HRT.onPrimary : HRT.onSurfaceVariant;

  // border for today (only when not selected)
  const border = isToday && !isSelected ? `1.5px solid ${HRT.primary}` : '1.5px solid transparent';

  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        gap: 4, padding: '8px 0 6px',
        background: bg, border, borderRadius: 20,
        cursor: 'pointer', fontFamily: HRT_FONT,
        transition: 'background-color 200ms, transform 150ms',
        minHeight: 64,
      }}
    >
      <span style={{
        fontSize: 11, fontWeight: 500, letterSpacing: 0.5,
        color: dowColor, textTransform: 'uppercase',
      }}>{dowLabel}</span>
      <span style={{
        fontSize: 18, fontWeight: isSelected ? 700 : (isToday ? 700 : 500),
        lineHeight: '22px', color: fg, fontVariantNumeric: 'tabular-nums',
      }}>{dayNum}</span>
      <DayStatusDot status={status} isPast={isPast} isSelected={isSelected} />
    </button>
  );
}

function DayStatusDot({ status, isPast, isSelected }) {
  const neutral = isSelected ? 'rgba(255,255,255,0.55)' : HRT.outline;

  if (status === 'fulfilled') {
    return (
      <Icon name="check" size={14} color={isSelected ? HRT.onPrimary : HRT.statusFulfilled} fill={1} weight={700} />
    );
  }
  if (status === 'overdue') {
    return (
      <div style={{
        width: 8, height: 8, borderRadius: 4,
        border: `1.5px solid ${isSelected ? HRT.onPrimary : HRT.statusOverdue}`,
        boxSizing: 'border-box',
      }} />
    );
  }
  if (status === 'partial') {
    const color = isSelected ? HRT.onPrimary : HRT.statusPartial;
    return (
      <svg width="12" height="12" viewBox="0 0 12 12">
        <circle cx="6" cy="6" r="4.5" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 6 1.5 A 4.5 4.5 0 0 1 6 10.5" fill={color} />
      </svg>
    );
  }
  if (status === 'scheduled') {
    return (
      <div style={{
        width: 8, height: 8, borderRadius: 4,
        border: `1.5px solid ${neutral}`, boxSizing: 'border-box',
      }} />
    );
  }
  if (status === 'unplanned') {
    return (
      <div style={{ width: 5, height: 5, borderRadius: 3, background: neutral }} />
    );
  }
  // none
  return (
    <div style={{ width: 10, height: 2, borderRadius: 1, background: neutral, opacity: 0.6 }} />
  );
}

Object.assign(window, { WeekStrip, DayStatusDot });
