// E2 hero — big dominant concentration card
function E2Hero() {
  const { e2 } = HOME_DATA;
  const inRange = e2.currentValue >= e2.targetMin && e2.currentValue <= e2.targetMax;
  const trendArrow = e2.trend > 0 ? 'trending_up' : e2.trend < 0 ? 'trending_down' : 'trending_flat';
  const trendLabel = e2.trend > 0 ? `+${e2.trendAbs}` : e2.trend < 0 ? `−${e2.trendAbs}` : '±0';

  return (
    <div style={{
      margin: '8px 16px 4px', padding: '20px 22px 20px',
      background: HRT.primaryContainer, borderRadius: 28,
      fontFamily: HRT_FONT, position: 'relative', overflow: 'hidden',
    }}>
      {/* watermark droplet */}
      <div style={{
        position: 'absolute', right: -20, top: -20, opacity: 0.14,
        color: HRT.onPrimaryContainer, pointerEvents: 'none',
      }}>
        <Icon name="water_drop" size={160} fill={1} />
      </div>

      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, position: 'relative' }}>
        <span style={{
          fontSize: 11, fontWeight: 700, letterSpacing: 1,
          color: HRT.onPrimaryContainer, textTransform: 'uppercase',
        }}>Estradiol · estimated</span>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 3,
          padding: '2px 8px', borderRadius: 9999,
          background: inRange ? HRT.tertiaryContainer : 'rgba(113,51,66,0.15)',
          color: inRange ? HRT.onTertiaryContainer : HRT.onPrimaryContainer,
          fontSize: 10, fontWeight: 700, letterSpacing: 0.5,
        }}>
          <span style={{
            width: 6, height: 6, borderRadius: 3,
            background: inRange ? HRT.statusFulfilled : HRT.statusPartial,
          }} />
          {inRange ? 'IN RANGE' : 'BELOW RANGE'}
        </div>
      </div>

      {/* big number */}
      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 8,
        marginTop: 10, position: 'relative',
      }}>
        <span style={{
          fontSize: 64, lineHeight: '64px', fontWeight: 500,
          color: HRT.onPrimaryContainer, letterSpacing: -2,
          fontVariantNumeric: 'tabular-nums',
        }}>{e2.currentValue}</span>
        <span style={{
          fontSize: 16, fontWeight: 500, color: HRT.onPrimaryContainer,
          letterSpacing: 0.2, opacity: 0.75,
        }}>{e2.unit}</span>
      </div>

      {/* footer row: trend + last dose */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        marginTop: 10, position: 'relative',
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          padding: '5px 10px 5px 8px', borderRadius: 9999,
          background: 'rgba(255,255,255,0.45)',
          color: HRT.onPrimaryContainer, fontSize: 12, fontWeight: 600,
          letterSpacing: 0.2,
        }}>
          <Icon name={trendArrow} size={14} fill={1} />
          <span style={{ fontVariantNumeric: 'tabular-nums' }}>{trendLabel} since yesterday</span>
        </div>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          color: HRT.onPrimaryContainer, fontSize: 12, fontWeight: 500,
          opacity: 0.85, letterSpacing: 0.2,
        }}>
          <Icon name="schedule" size={13} fill={0} />
          <span>Last dose {e2.sinceE2Label}</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { E2Hero });
