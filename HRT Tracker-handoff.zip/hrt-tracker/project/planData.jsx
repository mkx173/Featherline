// Mock data for the Plan screen - April 2026, today = Apr 18 (Sat)
const PLAN_DATA = (() => {
  const today = new Date(2026, 3, 18); // Apr 18, 2026 (Sat)
  const year = 2026, month = 3;
  // Build a month worth of day states
  const dayState = {}; // dateKey → { expected, matched, hasUnplanned }
  const set = (d, expected, matched, unp = false) => { dayState[d] = { expected, matched, hasUnplanned: unp }; };
  // simulated history (daily spironolactone every day, weekly estradiol IM on Wednesdays)
  // daily spiro: 2 doses (morning + evening). Weekly E: 1 dose Wed.
  for (let d = 1; d <= 30; d++) {
    const date = new Date(year, month, d);
    const dow = date.getDay(); // 0=Sun
    const isWed = dow === 3;
    const expected = 2 + (isWed ? 1 : 0);
    // historical: d <= 17 mostly fulfilled with some misses; 18=today partial; future unscheduled
    let matched = 0;
    if (d < 18) {
      // realistic adherence pattern
      if ([3, 5, 7, 8, 10, 11, 12, 14, 15, 16].includes(d)) matched = expected; // fulfilled
      else if (d === 4) matched = 1; // partial
      else if (d === 13) matched = expected - 1; // partial (1 of 3)
      else if (d === 17) matched = 0; // overdue
      else matched = expected; // default fulfilled for others
    } else if (d === 18) {
      matched = 1; // partial today (1 of 2 doses done so far)
    } else {
      matched = 0; // future
    }
    set(d, expected, matched);
  }
  // a couple of unplanned (manual only) days
  dayState[2].hasUnplanned = true; dayState[2].expected = 0; dayState[2].matched = 0;
  dayState[6].hasUnplanned = true; dayState[6].expected = 0; dayState[6].matched = 0;

  const status = (d) => {
    const s = dayState[d];
    if (!s) return 'none';
    if (s.expected <= 0 && s.hasUnplanned) return 'unplanned';
    if (s.expected <= 0) return 'none';
    if (s.matched <= 0) {
      const isPast = d < 18;
      return isPast ? 'overdue' : 'scheduled';
    }
    if (s.matched < s.expected) return 'partial';
    return 'fulfilled';
  };

  // Records for today (Apr 18)
  const todaysRecords = [
    {
      id: 'r1', name: 'Spironolactone', dose: 100, unit: 'mg', route: 'Oral',
      time: '08:00', scheduledTime: '08:00', status: 'done',
      source: 'group', group: 'Daily spironolactone',
    },
    {
      id: 'r2', name: 'Estradiol valerate', dose: 5.0, unit: 'mg', route: 'Intramuscular',
      time: null, scheduledTime: '13:30', status: 'due-soon',
      source: 'group', group: 'Weekly estradiol IM',
    },
    {
      id: 'r3', name: 'Spironolactone', dose: 100, unit: 'mg', route: 'Oral',
      time: null, scheduledTime: '20:00', status: 'upcoming',
      source: 'group', group: 'Daily spironolactone',
    },
  ];

  // Medication groups
  const groups = [
    {
      id: 'g1', name: 'Weekly estradiol IM',
      cadence: 'Every Wed', time: '13:30',
      meds: [{ name: 'Estradiol valerate', dose: '5.0 mg', route: 'IM' }],
      nextDose: 'Today, 13:30', accent: 'primary',
    },
    {
      id: 'g2', name: 'Daily spironolactone',
      cadence: 'Daily', time: '08:00 · 20:00',
      meds: [
        { name: 'Spironolactone', dose: '100 mg', route: 'Oral' },
        { name: 'Spironolactone', dose: '100 mg', route: 'Oral' },
      ],
      nextDose: 'Today, 20:00', accent: 'tertiary',
    },
    {
      id: 'g3', name: 'Progesterone at bedtime',
      cadence: 'Daily', time: '22:00',
      meds: [{ name: 'Micronized progesterone', dose: '100 mg', route: 'Oral' }],
      nextDose: 'Today, 22:00', accent: 'tonal',
    },
  ];

  return { today, dayState, status, todaysRecords, groups };
})();

// Week strip: shows a single week; the current week contains "today"
function buildWeekStrip(centerDate, offsetWeeks = 0) {
  // Monday-first week containing centerDate
  const d = new Date(centerDate);
  d.setDate(d.getDate() + offsetWeeks * 7);
  const dow = (d.getDay() + 6) % 7; // 0=Mon
  const monday = new Date(d);
  monday.setDate(d.getDate() - dow);
  const days = [];
  for (let i = 0; i < 7; i++) {
    const x = new Date(monday);
    x.setDate(monday.getDate() + i);
    days.push(x);
  }
  return days;
}

function monthName(d) {
  return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}
function dowShort(d) {
  return ['M','T','W','T','F','S','S'][(d.getDay()+6)%7];
}
function isSameDay(a, b) {
  return a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();
}

Object.assign(window, { PLAN_DATA, buildWeekStrip, monthName, dowShort, isSameDay });
