// Hero card — streak + adherence progress ring
function AdherenceHero({ variant = 'ring' }) {
  // 7-day adherence: count fulfilled days in past 7 (excluding today's partial)
  const days = [];
  for (let d = 11; d <= 17; d++) days.push(PLAN_DATA.status(d));
  const fulfilled = days.filter(s => s === 'fulfilled').length;
  const total = days.length;
  const pct = fulfilled / total;
  const streak = 3; // days in a row

  if (variant === 'banner') return <AdherenceBanner fulfilled={fulfilled} total={total} streak={streak} days={days} />;
  if (variant === 'compact') return <AdherenceCompact fulfilled={fulfilled} total={total} streak={streak} />;
  return <AdherenceRing fulfilled={fulfilled} total={total} streak={streak} pct={pct} />;
}

// Variant A: gentle progress ring + streak chip
function AdherenceRing({ fulfilled, total, streak, pct }) {
  const size = 76, stroke = 8, r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const filled = C * pct;
  return (
    <div style={{
      margin: '8px 16px 4px', padding: '16px 20px',
      background: HRT.surfaceContainerLow, borderRadius: 28,
      display: 'flex', alignItems: 'center', gap: 16,
      fontFamily: HRT_FONT,
    }}>
      <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size/2} cy={size/2} r={r} fill="none"
            stroke={HRT.surfaceContainerHigh} strokeWidth={stroke} />
          <circle cx={size/2} cy={size/2} r={r} fill="none"
            stroke={HRT.primary} strokeWidth={stroke} strokeLinecap="round"
            strokeDasharray={`${filled} ${C - filled}`} />
        </svg>
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexDirection: 'column', lineHeight: 1,
        }}>
          <span style={{ fontSize: 22, fontWeight: 600, color: HRT.onSurface, fontVariantNumeric: 'tabular-nums' }}>
            {fulfilled}<span style={{ fontSize: 14, color: HRT.onSurfaceVariant, fontWeight: 500 }}>/{total}</span>
          </span>
        </div>
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <div style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase' }}>
          This week
        </div>
        <div style={{ fontSize: 18, fontWeight: 500, color: HRT.onSurface, lineHeight: '24px' }}>
          On track
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: '4px 10px 4px 8px', borderRadius: 9999,
            background: HRT.tertiaryContainer, color: HRT.onTertiaryContainer,
          }}>
            <Icon name="local_fire_department" size={16} fill={1} />
            <span style={{ fontSize: 13, fontWeight: 600, letterSpacing: 0.1 }}>{streak}-day streak</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Variant B: banner with inline 7-dot row
function AdherenceBanner({ fulfilled, total, streak, days }) {
  return (
    <div style={{
      margin: '8px 16px 4px', padding: '20px 20px 18px',
      background: HRT.primaryContainer, borderRadius: 28,
      fontFamily: HRT_FONT, position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <Icon name="local_fire_department" size={20} fill={1} color={HRT.onPrimaryContainer} />
        <span style={{ fontSize: 13, fontWeight: 600, letterSpacing: 0.4, textTransform: 'uppercase', color: HRT.onPrimaryContainer }}>
          {streak}-day streak
        </span>
      </div>
      <div style={{ fontSize: 26, lineHeight: '32px', fontWeight: 400, color: HRT.onPrimaryContainer, letterSpacing: -0.2 }}>
        <span style={{ fontWeight: 600 }}>{fulfilled} of {total}</span> days on track this week
      </div>
      <div style={{ display: 'flex', gap: 6, marginTop: 14 }}>
        {days.map((s, i) => {
          const filled = s === 'fulfilled';
          const partial = s === 'partial';
          return (
            <div key={i} style={{
              flex: 1, height: 6, borderRadius: 3,
              background: filled ? HRT.primary
                : partial ? HRT.statusPartial
                : 'rgba(113,51,66,0.18)',
            }} />
          );
        })}
      </div>
    </div>
  );
}

// Variant C: compact single-line
function AdherenceCompact({ fulfilled, total, streak }) {
  return (
    <div style={{
      margin: '4px 16px 4px', padding: '12px 16px',
      background: HRT.surfaceContainerLow, borderRadius: 16,
      display: 'flex', alignItems: 'center', gap: 12,
      fontFamily: HRT_FONT,
    }}>
      <Icon name="local_fire_department" size={22} fill={1} color={HRT.tertiary} />
      <div style={{ flex: 1, fontSize: 14, color: HRT.onSurface, letterSpacing: 0.25 }}>
        <b style={{ fontWeight: 600 }}>{streak}-day streak</b>
        <span style={{ color: HRT.onSurfaceVariant }}> · {fulfilled}/{total} this week</span>
      </div>
      <Icon name="chevron_right" size={20} color={HRT.onSurfaceVariant} fill={0} />
    </div>
  );
}

Object.assign(window, { AdherenceHero });
