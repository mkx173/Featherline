// HRT Tracker design tokens (M3 Expressive, light scheme)
const HRT = {
  primary: '#8D4959',
  onPrimary: '#FFFFFF',
  primaryContainer: '#FFD9DF',
  onPrimaryContainer: '#713342',
  secondary: '#75565C',
  onSecondary: '#FFFFFF',
  secondaryContainer: '#FFD9DF',
  onSecondaryContainer: '#5B3F44',
  tertiary: '#7A5732',
  onTertiary: '#FFFFFF',
  tertiaryContainer: '#FFDCBC',
  onTertiaryContainer: '#5F401D',
  error: '#BA1A1A',
  errorContainer: '#FFDAD6',
  onErrorContainer: '#93000A',
  surface: '#FFF8F7',
  surfaceContainerLowest: '#FFFFFF',
  surfaceContainerLow: '#FFF0F1',
  surfaceContainer: '#FBEAEB',
  surfaceContainerHigh: '#F5E4E6',
  surfaceContainerHighest: '#EFDEE0',
  onSurface: '#22191B',
  onSurfaceVariant: '#524345',
  outline: '#847375',
  outlineVariant: '#D6C2C4',
  scrim: 'rgba(0,0,0,0.32)',
  statusFulfilled: '#2E7D32',
  statusOverdue: '#C62828',
  statusPartial: '#EF6C00',
};

const HRT_FONT = "'Roboto Flex','Roboto',system-ui,sans-serif";

// Material icon
const Icon = ({ name, size = 24, color = 'currentColor', fill = 1, weight = 400, grade = 0, opsz = 24, style }) => (
  <span className="material-symbols-rounded" style={{
    fontSize: size, color, lineHeight: 1,
    fontVariationSettings: `'FILL' ${fill}, 'wght' ${weight}, 'GRAD' ${grade}, 'opsz' ${opsz}`,
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    userSelect: 'none',
    ...style,
  }}>{name}</span>
);

// M3 ripple-lite: scale + state layer on press
function Pressable({ children, onClick, style, rippleColor = 'rgba(34,25,27,0.08)', disabled }) {
  const [pressed, setPressed] = React.useState(false);
  return (
    <button
      type="button"
      disabled={disabled}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      onClick={onClick}
      style={{
        position: 'relative', border: 'none', background: 'transparent', cursor: 'pointer',
        fontFamily: HRT_FONT, textAlign: 'left', padding: 0,
        transition: 'transform 150ms cubic-bezier(0.2,0,0,1), background-color 150ms',
        transform: pressed ? 'scale(0.985)' : 'scale(1)',
        ...style,
      }}
    >
      {children}
      {pressed && (
        <span style={{
          position: 'absolute', inset: 0, background: rippleColor,
          borderRadius: 'inherit', pointerEvents: 'none',
        }} />
      )}
    </button>
  );
}

// Top app bar
function TopBar({ title, trailing, scrolled = false }) {
  return (
    <div style={{
      height: 64, display: 'flex', alignItems: 'center',
      padding: '0 4px 0 16px', fontFamily: HRT_FONT,
      background: scrolled ? HRT.surfaceContainer : HRT.surface,
      transition: 'background-color 200ms',
      flexShrink: 0, zIndex: 5,
    }}>
      <div style={{ flex: 1, fontSize: 22, fontWeight: 500, letterSpacing: 0, color: HRT.onSurface }}>
        {title}
      </div>
      <div style={{ display: 'flex', gap: 4 }}>{trailing}</div>
    </div>
  );
}

// Icon button (circle, 40dp)
function IconButton({ icon, onClick, color, size = 40, iconSize = 24 }) {
  return (
    <Pressable onClick={onClick} style={{
      width: size, height: size, borderRadius: 9999,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      color: color || HRT.onSurfaceVariant,
    }}>
      <Icon name={icon} size={iconSize} fill={0} />
    </Pressable>
  );
}

// FAB (primary, extended and regular)
function FAB({ icon, label, onClick, variant = 'primary', extended = false, size = 'md' }) {
  const bgMap = {
    primary: HRT.primaryContainer,
    tonal: HRT.secondaryContainer,
    tertiary: HRT.tertiaryContainer,
  };
  const fgMap = {
    primary: HRT.onPrimaryContainer,
    tonal: HRT.onSecondaryContainer,
    tertiary: HRT.onTertiaryContainer,
  };
  const dims = size === 'sm' ? { h: 40, r: 12, ic: 20 } : { h: 56, r: 16, ic: 24 };
  return (
    <Pressable onClick={onClick} style={{
      height: dims.h, minWidth: dims.h, padding: extended ? '0 20px' : 0,
      borderRadius: dims.r, background: bgMap[variant], color: fgMap[variant],
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 12,
      boxShadow: '0 3px 8px rgba(34,25,27,0.18), 0 1px 3px rgba(34,25,27,0.12)',
    }}>
      <Icon name={icon} size={dims.ic} fill={1} />
      {extended && label && (
        <span style={{ fontSize: 14, fontWeight: 500, letterSpacing: 0.1, paddingRight: 4 }}>{label}</span>
      )}
    </Pressable>
  );
}

// Bottom nav
function BottomNav({ active, onNavigate }) {
  const tabs = [
    { id: 'home', icon: 'home', label: 'Home' },
    { id: 'plan', icon: 'calendar_month', label: 'Plan' },
    { id: 'history', icon: 'history', label: 'History' },
    { id: 'settings', icon: 'settings', label: 'Settings' },
  ];
  return (
    <div style={{
      display: 'flex', height: 80, padding: '12px 0 16px',
      background: HRT.surfaceContainer, fontFamily: HRT_FONT,
      flexShrink: 0,
    }}>
      {tabs.map(t => {
        const isActive = t.id === active;
        return (
          <button key={t.id} onClick={() => onNavigate(t.id)} style={{
            flex: 1, display: 'flex', flexDirection: 'column',
            alignItems: 'center', gap: 4, background: 'transparent',
            border: 'none', cursor: 'pointer', padding: '4px 0',
            color: isActive ? HRT.onSecondaryContainer : HRT.onSurfaceVariant,
          }}>
            <div style={{
              padding: '4px 20px', borderRadius: 9999,
              background: isActive ? HRT.secondaryContainer : 'transparent',
              transition: 'background 200ms',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name={t.icon} size={24} fill={isActive ? 1 : 0} />
            </div>
            <div style={{ fontSize: 12, fontWeight: isActive ? 600 : 500, letterSpacing: 0.5 }}>
              {t.label}
            </div>
          </button>
        );
      })}
    </div>
  );
}

Object.assign(window, { HRT, HRT_FONT, Icon, Pressable, TopBar, IconButton, FAB, BottomNav });
