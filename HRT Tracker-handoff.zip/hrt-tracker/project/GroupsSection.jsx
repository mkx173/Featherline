// GroupsSection — medication groups list in M3 Expressive style
function GroupsSection({ onEdit }) {
  const groups = PLAN_DATA.groups;
  return (
    <div style={{ padding: '16px 16px 24px', fontFamily: HRT_FONT }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '4px 4px 12px',
      }}>
        <span style={{
          fontSize: 13, fontWeight: 600, letterSpacing: 0.5,
          color: HRT.onSurfaceVariant, textTransform: 'uppercase',
        }}>Medication groups</span>
        <span style={{ fontSize: 13, color: HRT.onSurfaceVariant }}>{groups.length}</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {groups.map(g => <GroupCard key={g.id} group={g} onClick={() => onEdit(g.id)} />)}
      </div>
    </div>
  );
}

function GroupCard({ group, onClick }) {
  // M3 Expressive: outlined card with pill-tag medication chips
  const accentMap = {
    primary: { bg: HRT.primaryContainer, fg: HRT.onPrimaryContainer, dot: HRT.primary },
    tertiary: { bg: HRT.tertiaryContainer, fg: HRT.onTertiaryContainer, dot: HRT.tertiary },
    tonal: { bg: HRT.secondaryContainer, fg: HRT.onSecondaryContainer, dot: HRT.secondary },
  };
  const acc = accentMap[group.accent] || accentMap.primary;
  const routeAbbr = (r) => r === 'Intramuscular' ? 'IM' : r === 'Oral' ? 'Oral' : r;

  return (
    <Pressable onClick={onClick} style={{
      display: 'block',
      background: HRT.surfaceContainerLow,
      borderRadius: 20,
      padding: '14px 16px 14px',
      border: `1px solid ${HRT.outlineVariant}`,
    }}>
      {/* header row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 6, height: 36, borderRadius: 3, background: acc.dot, flexShrink: 0,
        }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 16, fontWeight: 600, color: HRT.onSurface,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>{group.name}</div>
          <div style={{
            fontSize: 12, color: HRT.onSurfaceVariant, letterSpacing: 0.2,
            marginTop: 2, display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <Icon name="schedule" size={14} fill={0} />
            <span>{group.cadence} · {group.time}</span>
          </div>
        </div>
        <Icon name="chevron_right" size={20} color={HRT.onSurfaceVariant} fill={0} />
      </div>

      {/* med pill tags */}
      <div style={{
        display: 'flex', flexWrap: 'wrap', gap: 6,
        marginTop: 12, paddingLeft: 16,
      }}>
        {group.meds.map((m, i) => (
          <div key={i} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px 4px 8px',
            background: acc.bg, color: acc.fg,
            borderRadius: 9999,
            fontSize: 12, fontWeight: 500, letterSpacing: 0.1,
          }}>
            <span style={{
              fontSize: 10, fontWeight: 700, letterSpacing: 0.3,
              padding: '1px 5px', borderRadius: 4,
              background: 'rgba(255,255,255,0.55)',
            }}>{routeAbbr(m.route)}</span>
            <span>{m.name}</span>
            <span style={{ opacity: 0.75, fontVariantNumeric: 'tabular-nums' }}>· {m.dose}</span>
          </div>
        ))}
      </div>

      {/* next-dose footer */}
      <div style={{
        marginTop: 12, paddingLeft: 16, paddingTop: 10,
        borderTop: `1px dashed ${HRT.outlineVariant}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 12, letterSpacing: 0.2,
      }}>
        <span style={{ color: HRT.onSurfaceVariant }}>Next dose</span>
        <span style={{ color: HRT.onSurface, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>
          {group.nextDose}
        </span>
      </div>
    </Pressable>
  );
}

Object.assign(window, { GroupsSection });
