// Today's schedule + tomorrow preview
function TodaySchedule({ onLog }) {
  const { today, tomorrow } = HOME_DATA;

  return (
    <div style={{ padding: '12px 16px 0', fontFamily: HRT_FONT }}>
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        padding: '8px 4px 10px',
      }}>
        <div style={{
          fontSize: 13, fontWeight: 700, letterSpacing: 0.5,
          color: HRT.onSurfaceVariant, textTransform: 'uppercase',
        }}>Today · Wed Apr 22</div>
        <div style={{ fontSize: 11, color: HRT.onSurfaceVariant, letterSpacing: 0.2 }}>
          {today.filter(t => t.status === 'done').length}/{today.length} done
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {today.map(item => <DoseRow key={item.id} item={item} onLog={onLog} />)}
      </div>

      <div style={{
        fontSize: 13, fontWeight: 700, letterSpacing: 0.5,
        color: HRT.onSurfaceVariant, textTransform: 'uppercase',
        padding: '20px 4px 10px',
      }}>Tomorrow · Thu Apr 23</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {tomorrow.map(item => <TomorrowRow key={item.id} item={item} />)}
      </div>
    </div>
  );
}

function DoseRow({ item, onLog }) {
  const done = item.status === 'done';
  const dueSoon = item.status === 'due-soon';

  const accentMap = {
    primary:   { bg: HRT.primaryContainer,   fg: HRT.onPrimaryContainer,   dot: HRT.primary },
    tonal:     { bg: HRT.secondaryContainer, fg: HRT.onSecondaryContainer, dot: HRT.secondary },
    tertiary:  { bg: HRT.tertiaryContainer,  fg: HRT.onTertiaryContainer,  dot: HRT.tertiary },
  };
  const acc = accentMap[item.accent] || accentMap.tonal;

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 14px', borderRadius: 20,
      background: dueSoon ? HRT.surfaceContainerHigh : HRT.surfaceContainerLow,
      border: dueSoon ? `1.5px solid ${HRT.primary}` : `1px solid ${HRT.outlineVariant}`,
      position: 'relative', overflow: 'hidden',
    }}>
      {/* time col */}
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        width: 44, flexShrink: 0,
      }}>
        <span style={{
          fontSize: 15, fontWeight: 700, color: HRT.onSurface,
          fontVariantNumeric: 'tabular-nums', letterSpacing: 0,
        }}>{item.time}</span>
        <span style={{
          fontSize: 9, fontWeight: 600, letterSpacing: 0.5,
          color: HRT.onSurfaceVariant, textTransform: 'uppercase', marginTop: 1,
        }}>{item.period.slice(0, 3)}</span>
      </div>

      {/* accent pill */}
      <div style={{
        width: 4, alignSelf: 'stretch', borderRadius: 2, background: acc.dot, flexShrink: 0,
      }} />

      {/* content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          fontSize: 14, fontWeight: 600, color: HRT.onSurface, letterSpacing: 0.1,
        }}>
          <span style={{
            fontSize: 9, fontWeight: 700, letterSpacing: 0.5,
            padding: '1px 5px', borderRadius: 4,
            background: acc.bg, color: acc.fg, textTransform: 'uppercase',
          }}>{item.route}</span>
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {item.name}
          </span>
        </div>
        <div style={{
          fontSize: 12, color: HRT.onSurfaceVariant,
          marginTop: 2, letterSpacing: 0.2,
        }}>
          {item.dose}
          {done && item.loggedAt && <span> · logged at {item.loggedAt}</span>}
          {dueSoon && <span style={{ color: HRT.primary, fontWeight: 600 }}> · due in ~2h</span>}
        </div>
      </div>

      {/* trailing action */}
      {done ? (
        <div style={{
          width: 36, height: 36, borderRadius: 18,
          background: HRT.tertiaryContainer,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          <Icon name="check" size={20} fill={1} color={HRT.statusFulfilled} weight={600} />
        </div>
      ) : (
        <Pressable onClick={() => onLog && onLog(item)} style={{
          padding: '8px 14px', borderRadius: 9999,
          background: dueSoon ? HRT.primary : 'transparent',
          color: dueSoon ? HRT.onPrimary : HRT.primary,
          border: dueSoon ? 'none' : `1px solid ${HRT.outline}`,
          fontSize: 12, fontWeight: 600, letterSpacing: 0.2,
          display: 'inline-flex', alignItems: 'center', gap: 4, flexShrink: 0,
        }}>
          {dueSoon ? 'Log now' : 'Log'}
        </Pressable>
      )}
    </div>
  );
}

function TomorrowRow({ item }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '8px 14px', borderRadius: 14,
      background: 'transparent',
    }}>
      <span style={{
        fontSize: 12, fontWeight: 600, color: HRT.onSurfaceVariant,
        fontVariantNumeric: 'tabular-nums', width: 44,
      }}>{item.time}</span>
      <span style={{
        fontSize: 9, fontWeight: 700, letterSpacing: 0.5,
        padding: '1px 5px', borderRadius: 4,
        background: HRT.surfaceContainerHigh, color: HRT.onSurfaceVariant,
        textTransform: 'uppercase',
      }}>{item.route}</span>
      <span style={{
        flex: 1, fontSize: 13, color: HRT.onSurfaceVariant, letterSpacing: 0.1,
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>
        {item.name} · <span style={{ opacity: 0.75 }}>{item.dose}</span>
      </span>
    </div>
  );
}

Object.assign(window, { TodaySchedule });
