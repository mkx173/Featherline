// EntriesList — grouped by day, each with a header + entry cards
// Props: entries (array, sorted desc by time), selectedKey (optional, scrolls to)
function EntriesList({ entries, title }) {
  // group by YYYY-MM-DD
  const groups = {};
  for (const e of entries) {
    const k = HISTORY_DATA.key(e.when);
    if (!groups[k]) groups[k] = [];
    groups[k].push(e);
  }
  const sortedKeys = Object.keys(groups).sort((a, b) => (a < b ? 1 : -1));

  return (
    <div style={{ padding: '8px 16px 0', fontFamily: HRT_FONT }}>
      {title && (
        <div style={{
          fontSize: 13, fontWeight: 700, letterSpacing: 0.5,
          color: HRT.onSurfaceVariant, textTransform: 'uppercase',
          padding: '8px 4px 6px',
        }}>{title}</div>
      )}

      {sortedKeys.length === 0 && (
        <div style={{
          padding: 36, textAlign: 'center',
          color: HRT.onSurfaceVariant, fontSize: 14,
        }}>
          No entries in this month.
        </div>
      )}

      {sortedKeys.map(k => (
        <DayGroup key={k} dayKey={k} entries={groups[k]} />
      ))}
    </div>
  );
}

function DayGroup({ dayKey, entries }) {
  const [y, m, d] = dayKey.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  const info = HISTORY_DATA.dayStatus[dayKey] || { status: 'none' };
  const isToday = dayKey === HISTORY_DATA.key(HISTORY_DATA.TODAY);
  const weekday = date.toLocaleDateString('en-US', { weekday: 'short' });
  const dayLabel = isToday ? 'Today' : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div style={{ marginBottom: 14 }}>
      {/* Day header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '10px 4px 8px',
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '4px 10px 4px 8px', borderRadius: 9999,
          background: isToday ? HRT.primaryContainer : HRT.surfaceContainerHigh,
          color: isToday ? HRT.onPrimaryContainer : HRT.onSurface,
        }}>
          <DayStatusDot status={info.status} />
          <span style={{
            fontSize: 12, fontWeight: 700, letterSpacing: 0.3,
            fontVariantNumeric: 'tabular-nums',
          }}>{dayLabel}</span>
          <span style={{
            fontSize: 10, fontWeight: 600, letterSpacing: 0.5,
            opacity: 0.65, textTransform: 'uppercase',
          }}>{weekday}</span>
        </div>
        <div style={{
          flex: 1, height: 1, background: HRT.outlineVariant, opacity: 0.5,
        }} />
        <div style={{
          fontSize: 11, fontWeight: 500, letterSpacing: 0.3,
          color: HRT.onSurfaceVariant, fontVariantNumeric: 'tabular-nums',
        }}>
          {entries.length}
        </div>
      </div>

      {/* Entries */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {entries.map((e, i) => <EntryRow key={e.id} entry={e} />)}
      </div>
    </div>
  );
}

function EntryRow({ entry }) {
  // Source → icon
  const sourceIcon = {
    group_schedule: 'calendar_month',
    group_manual:   'checklist',
    manual:         'edit',
  }[entry.source] || 'edit';
  const sourceLabel = {
    group_schedule: 'On schedule',
    group_manual:   'Group · manual',
    manual:         'Manual',
  }[entry.source];

  // Route chip color
  const routeAccent = entry.route === 'IM' ? 'primary'
    : entry.route === 'SL' ? 'tertiary'
    : 'tonal';
  const accentMap = {
    primary:  { bg: HRT.primaryContainer,   fg: HRT.onPrimaryContainer },
    tonal:    { bg: HRT.secondaryContainer, fg: HRT.onSecondaryContainer },
    tertiary: { bg: HRT.tertiaryContainer,  fg: HRT.onTertiaryContainer },
  };
  const acc = accentMap[routeAccent];

  const timeLabel = entry.when.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 14px', borderRadius: 18,
      background: HRT.surfaceContainerLow,
      border: `1px solid ${HRT.outlineVariant}`,
      fontFamily: HRT_FONT,
    }}>
      {/* source icon chip */}
      <div style={{
        width: 36, height: 36, borderRadius: 12,
        background: HRT.surfaceContainerHigh,
        color: HRT.onSurfaceVariant,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
      }} title={sourceLabel}>
        <Icon name={sourceIcon} size={18} fill={0} />
      </div>

      {/* content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2,
        }}>
          <span style={{
            fontSize: 9, fontWeight: 700, letterSpacing: 0.5,
            padding: '1px 5px', borderRadius: 4,
            background: acc.bg, color: acc.fg, textTransform: 'uppercase',
          }}>{entry.route}</span>
          <span style={{
            fontSize: 14, fontWeight: 600, color: HRT.onSurface, letterSpacing: 0.1,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>{entry.name}</span>
        </div>
        <div style={{
          fontSize: 12, color: HRT.onSurfaceVariant, letterSpacing: 0.2,
        }}>
          {entry.dose} {entry.unit}
          {entry.group && <span style={{ opacity: 0.6 }}> · {entry.group}</span>}
        </div>
      </div>

      {/* time */}
      <div style={{
        fontSize: 13, fontWeight: 600, color: HRT.onSurface,
        fontVariantNumeric: 'tabular-nums', letterSpacing: 0,
        flexShrink: 0,
      }}>{timeLabel}</div>
    </div>
  );
}

Object.assign(window, { EntriesList });
