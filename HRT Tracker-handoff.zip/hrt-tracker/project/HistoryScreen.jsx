// HistoryScreen — monthly calendar + entries for that month, with swipe nav
function HistoryScreen() {
  // Start on April 2026 (TODAY's month)
  const today = HISTORY_DATA.TODAY;
  const [year, setYear] = React.useState(today.getFullYear());
  const [month0, setMonth0] = React.useState(today.getMonth()); // 0=Jan, 3=Apr
  const [selectedKey, setSelectedKey] = React.useState(null); // null = show whole month
  const [scrolled, setScrolled] = React.useState(false);

  // Bounds: earliest Feb 2026, latest May 2026
  const MIN = { y: 2026, m: 1 };
  const MAX = { y: 2026, m: 4 };
  const atMin = year === MIN.y && month0 === MIN.m;
  const atMax = year === MAX.y && month0 === MAX.m;

  const prevMonth = () => {
    if (atMin) return;
    setSelectedKey(null);
    if (month0 === 0) { setYear(year - 1); setMonth0(11); }
    else setMonth0(month0 - 1);
  };
  const nextMonth = () => {
    if (atMax) return;
    setSelectedKey(null);
    if (month0 === 11) { setYear(year + 1); setMonth0(0); }
    else setMonth0(month0 + 1);
  };

  // Summary for displayed month
  const summary = HISTORY_DATA.summaryForMonth(year, month0);

  // Entries visible: either for selected day or whole month
  const visibleEntries = React.useMemo(() => {
    if (selectedKey) return HISTORY_DATA.entriesForDay(selectedKey);
    return HISTORY_DATA.entriesForMonth(year, month0);
  }, [year, month0, selectedKey]);

  const listTitle = selectedKey
    ? `Records on ${(() => {
        const [y, m, d] = selectedKey.split('-').map(Number);
        return new Date(y, m-1, d).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
      })()}`
    : `${new Date(year, month0, 1).toLocaleDateString('en-US', { month: 'long' })} entries`;

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      background: HRT.surface, fontFamily: HRT_FONT,
      position: 'relative', overflow: 'hidden',
    }}>
      <TopBar
        title="History"
        scrolled={scrolled}
        trailing={<>
          <IconButton icon="search" />
          <IconButton icon="more_vert" />
        </>}
      />

      <div
        onScroll={(e) => setScrolled(e.target.scrollTop > 4)}
        style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}
      >
        {/* Month summary card — the "briefing" above the calendar */}
        <MonthSummaryCard year={year} month0={month0} summary={summary} />

        {/* Calendar */}
        <MonthCalendar
          year={year}
          month0={month0}
          selectedKey={selectedKey}
          onSelect={(k) => setSelectedKey(k === selectedKey ? null : k)}
          onPrev={atMin ? null : prevMonth}
          onNext={atMax ? null : nextMonth}
        />

        {/* Legend */}
        <CalendarLegend />

        {/* Divider */}
        <div style={{ height: 1, background: HRT.outlineVariant, margin: '4px 16px 0', opacity: 0.5 }} />

        {/* Entries */}
        <EntriesList entries={visibleEntries} title={listTitle} />

        {/* Selected-day clear button */}
        {selectedKey && (
          <div style={{ padding: '4px 16px 16px', display: 'flex', justifyContent: 'center' }}>
            <Pressable onClick={() => setSelectedKey(null)} style={{
              padding: '8px 14px', borderRadius: 9999,
              background: 'transparent',
              color: HRT.primary, fontSize: 12, fontWeight: 600, letterSpacing: 0.1,
              border: `1px solid ${HRT.outline}`,
              display: 'inline-flex', alignItems: 'center', gap: 4,
            }}>
              <Icon name="close" size={14} fill={0} />
              Clear selection
            </Pressable>
          </div>
        )}

        <div style={{ height: 48 }} />
      </div>
    </div>
  );
}

// Month summary: chips showing logged / on-track / partial / missed
function MonthSummaryCard({ year, month0, summary }) {
  const monthLabel = new Date(year, month0, 1).toLocaleDateString('en-US', { month: 'long' });
  return (
    <div style={{
      margin: '8px 16px 4px', padding: '14px 18px',
      background: HRT.surfaceContainerLow, borderRadius: 24,
      fontFamily: HRT_FONT,
    }}>
      <div style={{
        fontSize: 11, fontWeight: 700, letterSpacing: 1,
        color: HRT.onSurfaceVariant, textTransform: 'uppercase',
      }}>{monthLabel} summary</div>
      <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <StatChip icon="receipt_long" value={summary.logged} label="logged" tone="primary" />
        <StatChip icon="check" value={summary.onTrack} label="on-track" tone="fulfilled" />
        {summary.partial > 0 && <StatChip icon="pie_chart" value={summary.partial} label="partial" tone="partial" />}
        {summary.missed > 0 && <StatChip icon="circle" value={summary.missed} label="missed" tone="missed" />}
      </div>
    </div>
  );
}

function StatChip({ icon, value, label, tone }) {
  const toneMap = {
    primary:   { bg: HRT.primaryContainer,   fg: HRT.onPrimaryContainer,   dot: HRT.primary },
    fulfilled: { bg: '#E5F0E5',              fg: '#1C4D20',                dot: HRT.statusFulfilled },
    partial:   { bg: '#FCEEDA',              fg: '#7A4006',                dot: HRT.statusPartial },
    missed:    { bg: '#FFD9D6',              fg: '#8C1C1C',                dot: HRT.statusOverdue },
  };
  const t = toneMap[tone] || toneMap.primary;
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '6px 12px 6px 8px', borderRadius: 9999,
      background: t.bg, color: t.fg,
      fontFamily: HRT_FONT,
    }}>
      <Icon name={icon} size={14} fill={1} color={t.dot} />
      <span style={{ fontSize: 14, fontWeight: 700, fontVariantNumeric: 'tabular-nums', letterSpacing: 0 }}>{value}</span>
      <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0.3, opacity: 0.85 }}>{label}</span>
    </div>
  );
}

// Compact legend for the dot system
function CalendarLegend() {
  const items = [
    { status: 'fulfilled', label: 'On track' },
    { status: 'partial',   label: 'Partial' },
    { status: 'overdue',   label: 'Missed' },
    { status: 'unplanned', label: 'Unplanned' },
  ];
  return (
    <div style={{
      display: 'flex', gap: 12, flexWrap: 'wrap',
      justifyContent: 'center', padding: '6px 16px 10px',
      fontFamily: HRT_FONT,
    }}>
      {items.map(i => (
        <div key={i.status} style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          fontSize: 10, fontWeight: 500, letterSpacing: 0.3,
          color: HRT.onSurfaceVariant,
        }}>
          <DayStatusDot status={i.status} />
          <span>{i.label}</span>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { HistoryScreen });
