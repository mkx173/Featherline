// DayRecordList — flat, retrospective list (no "now" marker, no timeline)
function DayRecordList({ selectedDate, records }) {
  const d = selectedDate;
  const today = PLAN_DATA.today;
  const isToday = isSameDay(d, today);
  const isPast = d < today && !isToday;
  const isFuture = d > today && !isToday;
  const dayNum = d.getDate();
  const status = PLAN_DATA.status(dayNum);

  // summary text
  let summary = '';
  let summaryColor = HRT.onSurfaceVariant;
  if (records.length === 0) {
    summary = isFuture ? 'Nothing planned yet' : 'No doses logged';
  } else {
    const done = records.filter(r => r.status === 'done').length;
    summary = `${done} of ${records.length} doses ${isPast ? 'completed' : isToday ? 'so far' : 'scheduled'}`;
    if (status === 'fulfilled' && !isFuture) summaryColor = HRT.statusFulfilled;
    if (status === 'overdue') summaryColor = HRT.statusOverdue;
    if (status === 'partial') summaryColor = HRT.statusPartial;
  }

  return (
    <div style={{ padding: '12px 16px 4px', fontFamily: HRT_FONT }}>
      <div style={{ padding: '4px 4px 12px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 500, color: HRT.onSurface, letterSpacing: 0 }}>
            {d.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
          </div>
          <div style={{ fontSize: 13, color: summaryColor, marginTop: 2, fontWeight: summaryColor !== HRT.onSurfaceVariant ? 500 : 400 }}>
            {summary}
          </div>
        </div>
        {isToday && (
          <div style={{
            display: 'inline-flex', alignItems: 'center',
            padding: '4px 10px', borderRadius: 9999,
            background: HRT.secondaryContainer, color: HRT.onSecondaryContainer,
            fontSize: 12, fontWeight: 600, letterSpacing: 0.2,
          }}>Today</div>
        )}
      </div>

      {records.length === 0 ? (
        <div style={{
          padding: '24px 16px 8px', textAlign: 'center',
          color: HRT.onSurfaceVariant, fontSize: 13, letterSpacing: 0.2,
        }}>No records for this day.</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {records.map((r, i) => (
            <DayRecordRow key={r.id} record={r} isPast={isPast} isFuture={isFuture} first={i===0} last={i===records.length-1} />
          ))}
        </div>
      )}
    </div>
  );
}

function DayRecordRow({ record, isPast, isFuture, first, last }) {
  const st = record.status;
  const done = st === 'done';
  // For future days, all records are "upcoming"; for past, anything not done = missed
  const rowState = isFuture ? 'upcoming' : done ? 'done' : isPast ? 'missed' : st;

  const leading = (() => {
    if (rowState === 'done') return (
      <div style={{
        width: 28, height: 28, borderRadius: 14, background: HRT.statusFulfilled,
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff',
      }}>
        <Icon name="check" size={18} fill={1} weight={700} />
      </div>
    );
    if (rowState === 'missed') return (
      <div style={{
        width: 28, height: 28, borderRadius: 14, background: 'transparent',
        border: `2px solid ${HRT.statusOverdue}`, boxSizing: 'border-box',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: HRT.statusOverdue,
      }}>
        <Icon name="close" size={16} fill={1} weight={700} />
      </div>
    );
    if (rowState === 'due-soon') return (
      <div style={{
        width: 28, height: 28, borderRadius: 14, background: HRT.primaryContainer,
        border: `2px solid ${HRT.primary}`, boxSizing: 'border-box',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: HRT.onPrimaryContainer,
      }}>
        <Icon name="schedule" size={14} fill={1} weight={600} />
      </div>
    );
    // upcoming
    return (
      <div style={{
        width: 28, height: 28, borderRadius: 14, background: 'transparent',
        border: `1.5px solid ${HRT.outline}`, boxSizing: 'border-box',
      }} />
    );
  })();

  const labelText = rowState === 'done' ? 'Logged'
    : rowState === 'missed' ? 'Missed'
    : rowState === 'due-soon' ? 'Due'
    : 'Planned';

  const labelColor = rowState === 'done' ? HRT.statusFulfilled
    : rowState === 'missed' ? HRT.statusOverdue
    : rowState === 'due-soon' ? HRT.primary
    : HRT.onSurfaceVariant;

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '10px 4px',
      borderTop: first ? 'none' : `1px solid ${HRT.outlineVariant}`,
    }}>
      {leading}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 500, color: HRT.onSurface, lineHeight: '20px' }}>
          {record.name}
        </div>
        <div style={{ fontSize: 12, color: HRT.onSurfaceVariant, marginTop: 1, letterSpacing: 0.2 }}>
          {record.dose} {record.unit} · {record.route}
        </div>
      </div>
      <div style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: HRT.onSurface, letterSpacing: 0.2 }}>
          {record.scheduledTime}
        </div>
        <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: 0.5, textTransform: 'uppercase', color: labelColor, marginTop: 1 }}>
          {labelText}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DayRecordList });
