// RegimenSection — bigger group cards with next 3 occurrences + regimen summary header
function RegimenSection({ onEdit }) {
  const groups = PLAN_DATA.groups;
  const daily = groups.filter(g => g.cadence === 'Daily').length;
  const weekly = groups.filter(g => g.cadence.startsWith('Every')).length;

  return (
    <div style={{ padding: '8px 16px 24px', fontFamily: HRT_FONT }}>
      {/* regimen summary header */}
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        padding: '12px 4px 14px',
      }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase' }}>
            Regimen
          </div>
          <div style={{ fontSize: 13, color: HRT.onSurfaceVariant, marginTop: 4, letterSpacing: 0.2 }}>
            {groups.length} groups · {daily} daily · {weekly} weekly
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {groups.map(g => <BigGroupCard key={g.id} group={g} onClick={() => onEdit(g.id)} />)}
      </div>
    </div>
  );
}

function BigGroupCard({ group, onClick }) {
  const accentMap = {
    primary:   { bg: HRT.primaryContainer,   fg: HRT.onPrimaryContainer,   dot: HRT.primary },
    tertiary:  { bg: HRT.tertiaryContainer,  fg: HRT.onTertiaryContainer,  dot: HRT.tertiary },
    tonal:     { bg: HRT.secondaryContainer, fg: HRT.onSecondaryContainer, dot: HRT.secondary },
  };
  const acc = accentMap[group.accent] || accentMap.primary;
  const routeAbbr = (r) => r === 'Intramuscular' ? 'IM' : r === 'Oral' ? 'Oral' : r;
  const nextThree = computeNextOccurrences(group, PLAN_DATA.today, 3);

  return (
    <Pressable onClick={onClick} style={{
      display: 'block',
      background: HRT.surfaceContainerLow,
      borderRadius: 24,
      padding: '16px 18px 14px',
      border: `1px solid ${HRT.outlineVariant}`,
    }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 6, height: 40, borderRadius: 3, background: acc.dot, flexShrink: 0 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 17, fontWeight: 600, color: HRT.onSurface, letterSpacing: 0,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>{group.name}</div>
          <div style={{
            fontSize: 12, color: HRT.onSurfaceVariant, letterSpacing: 0.2, marginTop: 3,
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <Icon name="schedule" size={14} fill={0} />
            <span>{group.cadence} · {group.time}</span>
          </div>
        </div>
        <Icon name="chevron_right" size={20} color={HRT.onSurfaceVariant} fill={0} />
      </div>

      {/* meds pill tags */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 12, paddingLeft: 18 }}>
        {group.meds.map((m, i) => (
          <div key={i} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px 4px 8px',
            background: acc.bg, color: acc.fg, borderRadius: 9999,
            fontSize: 12, fontWeight: 500, letterSpacing: 0.1,
          }}>
            <span style={{
              fontSize: 10, fontWeight: 700, letterSpacing: 0.3,
              padding: '1px 5px', borderRadius: 4,
              background: 'rgba(255,255,255,0.55)',
            }}>{routeAbbr(m.route)}</span>
            <span>{m.name}</span>
            <span style={{ opacity: 0.75, fontVariantNumeric: 'tabular-nums' }}>· {m.dose}</span>
          </div>
        ))}
      </div>

      {/* next 3 occurrences */}
      <div style={{
        marginTop: 14, paddingLeft: 18, paddingTop: 12,
        borderTop: `1px dashed ${HRT.outlineVariant}`,
      }}>
        <div style={{
          fontSize: 10, fontWeight: 600, letterSpacing: 0.5, textTransform: 'uppercase',
          color: HRT.onSurfaceVariant, marginBottom: 6,
        }}>Upcoming</div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {nextThree.map((occ, i) => (
            <div key={i} style={{
              display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start',
              padding: '6px 12px', borderRadius: 12,
              background: i === 0 ? HRT.surfaceContainerHigh : HRT.surfaceContainer,
              minWidth: 76,
            }}>
              <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: 0.5, textTransform: 'uppercase', color: HRT.onSurfaceVariant }}>
                {occ.label}
              </span>
              <span style={{ fontSize: 14, fontWeight: 600, color: HRT.onSurface, fontVariantNumeric: 'tabular-nums', marginTop: 1 }}>
                {occ.time}
              </span>
            </div>
          ))}
        </div>
      </div>
    </Pressable>
  );
}

// Compute next N occurrences for a mock group
function computeNextOccurrences(group, today, n) {
  const times = group.time.split(' · '); // "08:00" or "08:00 · 20:00"
  const out = [];
  const nowH = 11, nowM = 15; // "now" is Apr 18 11:15
  // start from today
  for (let dayOffset = 0; out.length < n && dayOffset < 14; dayOffset++) {
    const d = new Date(today); d.setDate(today.getDate() + dayOffset);
    const dow = d.getDay();
    const isWednesday = dow === 3;
    // scheduling rule based on cadence
    let scheduled = false;
    if (group.cadence === 'Daily') scheduled = true;
    else if (group.cadence.startsWith('Every Wed')) scheduled = isWednesday;
    if (!scheduled) continue;
    for (const t of times) {
      if (out.length >= n) break;
      const [hh, mm] = t.split(':').map(Number);
      // skip past times for today
      if (dayOffset === 0 && (hh < nowH || (hh === nowH && mm <= nowM))) continue;
      let label;
      if (dayOffset === 0) label = 'Today';
      else if (dayOffset === 1) label = 'Tomorrow';
      else label = d.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' });
      out.push({ label, time: t });
    }
  }
  return out.slice(0, n);
}

Object.assign(window, { RegimenSection });
