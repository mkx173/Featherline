// HomeScreen — stacked E2 hero → 7-day chart → antiandrogen → today list + tomorrow preview
function HomeScreen({ onLog }) {
  const [scrolled, setScrolled] = React.useState(false);
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      background: HRT.surface, fontFamily: HRT_FONT,
      position: 'relative', overflow: 'hidden',
    }}>
      <TopBar
        title="Home"
        scrolled={scrolled}
        trailing={<>
          <IconButton icon="notifications" />
          <IconButton icon="more_vert" />
        </>}
      />

      <div
        onScroll={(e) => setScrolled(e.target.scrollTop > 4)}
        style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}
      >
        <E2Hero />
        <E2Chart />
        <AntiandrogenCard />
        <TodaySchedule onLog={onLog} />
        <div style={{ height: 96 }} />
      </div>

      <div style={{ position: 'absolute', right: 16, bottom: 16 }}>
        <FAB icon="add" label="Log dose" extended variant="primary" onClick={() => onLog && onLog()} />
      </div>
    </div>
  );
}

Object.assign(window, { HomeScreen });
