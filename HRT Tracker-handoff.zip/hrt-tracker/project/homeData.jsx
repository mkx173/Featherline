// Home screen data — E2 concentration curve modeling + today/tomorrow dose lists.
// "Now" is Wed Apr 22, 2026 at 11:15. Last E2 IM injection was 6 days ago
// (Thu Apr 16, 13:30) so we're approaching the trough right before today's dose.
//
// Simple first-order PK model: C(t) = Dose * ka / (V*(ka-ke)) * (exp(-ke*t) - exp(-ka*t))
// plus baseline ~40 pg/mL. Values chosen to look realistic for 5mg EV IM:
// peaks ~280-320 pg/mL ~day 2-3, falls to ~120 pg/mL by day 7.

const HOME_DATA = (() => {
  const now = new Date(2026, 3, 22, 11, 15); // Wed Apr 22 11:15 (injection day)

  // last E2 injections (one per week, Wednesdays, 13:30)
  const injections = [
    new Date(2026, 3, 1, 13, 30),
    new Date(2026, 3, 8, 13, 30),
    new Date(2026, 3, 15, 13, 30), // most recent; 6d21h ago
  ];

  // PK model — estradiol valerate IM
  const ka = 0.6, ke = 0.42, V = 14, DOSE = 5.0;
  const baseline = 38;
  const amp = 620; // scale factor

  function concAt(t) {
    // t = Date object; compute sum of contributions from injections in last ~10 days
    let c = baseline;
    for (const inj of injections) {
      const days = (t - inj) / (1000 * 60 * 60 * 24);
      if (days < 0 || days > 10) continue;
      c += amp * (ka / (V * (ka - ke))) * (Math.exp(-ke * days) - Math.exp(-ka * days));
    }
    return Math.max(0, c);
  }

  // Build 7-day curve sampled every 2 hours, ending at "now"
  const startMs = now - 7 * 24 * 60 * 60 * 1000;
  const samples = [];
  for (let ms = startMs; ms <= +now + 10 * 60 * 1000; ms += 2 * 60 * 60 * 1000) {
    const t = new Date(ms);
    samples.push({ t, c: concAt(t) });
  }
  const nowValue = concAt(now);
  const yesterdayValue = concAt(new Date(+now - 24 * 60 * 60 * 1000));
  const trend = nowValue - yesterdayValue; // negative (descending toward trough)

  // Time since last E2 dose
  const lastE2 = injections[injections.length - 1];
  const hoursSinceE2 = Math.floor((now - lastE2) / (1000 * 60 * 60));
  const daysSinceE2 = Math.floor(hoursSinceE2 / 24);
  const remHoursE2 = hoursSinceE2 - daysSinceE2 * 24;
  const sinceE2Label = daysSinceE2 > 0 ? `${daysSinceE2}d ${remHoursE2}h ago` : `${hoursSinceE2}h ago`;

  // Last spironolactone dose: 08:00 this morning (today)
  const lastSpiro = new Date(2026, 3, 22, 8, 0);
  const hoursSinceSpiro = Math.floor((now - lastSpiro) / (1000 * 60 * 60));
  const remMinSpiro = Math.floor(((now - lastSpiro) / (1000 * 60)) % 60);
  const sinceSpiroLabel = `${hoursSinceSpiro}h ${remMinSpiro}m ago`;

  // Today's schedule — Wed: 2 spiro (08:00, 20:00) + E2 IM (13:30)
  const today = [
    { id: 't1', time: '08:00', period: 'morning', name: 'Spironolactone', dose: '100 mg', route: 'Oral',
      status: 'done', loggedAt: '08:04', group: 'Daily spironolactone', accent: 'tonal' },
    { id: 't2', time: '13:30', period: 'afternoon', name: 'Estradiol valerate', dose: '5.0 mg', route: 'IM',
      status: 'due-soon', loggedAt: null, group: 'Weekly estradiol IM', accent: 'primary' },
    { id: 't3', time: '20:00', period: 'evening', name: 'Spironolactone', dose: '100 mg', route: 'Oral',
      status: 'upcoming', loggedAt: null, group: 'Daily spironolactone', accent: 'tonal' },
  ];

  // Tomorrow: Thu — just 2 spiro
  const tomorrow = [
    { id: 'tm1', time: '08:00', name: 'Spironolactone', dose: '100 mg', route: 'Oral', accent: 'tonal' },
    { id: 'tm2', time: '20:00', name: 'Spironolactone', dose: '100 mg', route: 'Oral', accent: 'tonal' },
  ];

  return {
    now,
    e2: {
      currentValue: Math.round(nowValue),
      trend: Math.round(trend),
      trendAbs: Math.abs(Math.round(trend)),
      samples,
      sinceE2Label,
      lastE2Label: 'Thu Apr 16, 13:30',
      targetMin: 100,
      targetMax: 200,
      unit: 'pg/mL',
    },
    antiandrogen: {
      name: 'Spironolactone',
      sinceSpiroLabel,
      lastSpiroLabel: 'Today, 08:04',
      nextDose: 'Today, 20:00',
      hoursUntilNext: 8.75,
    },
    today,
    tomorrow,
  };
})();

Object.assign(window, { HOME_DATA });
