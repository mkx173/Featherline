// GroupEditor + MedicationEditor — M3 Expressive
// Reuses theme.jsx tokens and matches v2 visual language.

// ---------- Shared form primitives ----------
function TextField({ label, value, onChange, suffix, type = 'text', focused, onFocus, onBlur }) {
  const [internalFocus, setInternalFocus] = React.useState(false);
  const f = focused ?? internalFocus;
  return (
    <div style={{
      position: 'relative',
      border: f ? `2px solid ${HRT.primary}` : `1px solid ${HRT.outline}`,
      borderRadius: 8, padding: f ? '13px 15px' : '14px 16px',
      background: 'transparent', fontFamily: HRT_FONT,
      display: 'flex', alignItems: 'center', gap: 8,
    }}>
      <div style={{
        position: 'absolute', top: -8, left: 12,
        background: HRT.surface, padding: '0 4px',
        fontSize: 12, fontWeight: 500, letterSpacing: 0.4,
        color: f ? HRT.primary : HRT.onSurfaceVariant,
      }}>{label}</div>
      <input
        type={type} value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => { setInternalFocus(true); onFocus && onFocus(); }}
        onBlur={() => { setInternalFocus(false); onBlur && onBlur(); }}
        style={{
          flex: 1, border: 'none', outline: 'none', background: 'transparent',
          fontSize: 16, color: HRT.onSurface, fontFamily: HRT_FONT,
          fontVariantNumeric: 'tabular-nums',
        }}
      />
      {suffix && (
        <span style={{ fontSize: 14, color: HRT.onSurfaceVariant, letterSpacing: 0.25 }}>
          {suffix}
        </span>
      )}
    </div>
  );
}

function FieldRow({ label, value, trailing, onClick, icon }) {
  return (
    <Pressable onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '14px 16px', borderRadius: 16,
      background: HRT.surfaceContainerLow,
      width: '100%', border: `1px solid ${HRT.outlineVariant}`,
    }}>
      {icon && <Icon name={icon} size={22} color={HRT.onSurfaceVariant} fill={0} />}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase' }}>
          {label}
        </div>
        <div style={{ fontSize: 16, fontWeight: 500, color: HRT.onSurface, marginTop: 1, fontVariantNumeric: 'tabular-nums' }}>
          {value}
        </div>
      </div>
      {trailing}
    </Pressable>
  );
}

// M3 Expressive segmented button
function Segmented({ options, value, onChange }) {
  return (
    <div style={{
      display: 'flex', width: '100%',
      border: `1px solid ${HRT.outline}`, borderRadius: 9999,
      overflow: 'hidden', fontFamily: HRT_FONT,
    }}>
      {options.map((o, i) => {
        const sel = o.value === value;
        return (
          <button key={o.value} onClick={() => onChange(o.value)}
            style={{
              flex: 1, padding: '10px 16px', border: 'none', cursor: 'pointer',
              background: sel ? HRT.secondaryContainer : 'transparent',
              color: sel ? HRT.onSecondaryContainer : HRT.onSurface,
              fontSize: 14, fontWeight: sel ? 600 : 500, letterSpacing: 0.1,
              borderLeft: i > 0 ? `1px solid ${HRT.outline}` : 'none',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              transition: 'background 200ms',
            }}>
            {sel && <Icon name="check" size={18} fill={1} weight={600} />}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

// Filter-chip (for route selection, day-of-week)
function Chip({ label, selected, onClick, compact = false }) {
  return (
    <button onClick={onClick} style={{
      padding: compact ? '6px 12px' : '8px 14px',
      borderRadius: 9999,
      border: selected ? 'none' : `1px solid ${HRT.outline}`,
      background: selected ? HRT.secondaryContainer : 'transparent',
      color: selected ? HRT.onSecondaryContainer : HRT.onSurface,
      fontSize: compact ? 13 : 14, fontWeight: 500, letterSpacing: 0.1,
      fontFamily: HRT_FONT, cursor: 'pointer',
      display: 'inline-flex', alignItems: 'center', gap: 6,
      transition: 'background 150ms',
    }}>
      {selected && <Icon name="check" size={16} fill={1} weight={600} />}
      {label}
    </button>
  );
}

// Section header
function SectionHeader({ title, trailing }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '16px 4px 8px', fontFamily: HRT_FONT,
    }}>
      <span style={{
        fontSize: 13, fontWeight: 600, letterSpacing: 0.5,
        color: HRT.onSurfaceVariant, textTransform: 'uppercase',
      }}>{title}</span>
      {trailing}
    </div>
  );
}

// ---------- Group Editor Screen ----------
function GroupEditorScreen({ initialGroup, onBack, onSave, onDelete }) {
  const isEditing = !!initialGroup;
  const [name, setName] = React.useState(initialGroup?.name || '');
  const [scheduleType, setScheduleType] = React.useState(initialGroup?.scheduleType || 'weekly');
  const [sinceDate, setSinceDate] = React.useState(initialGroup?.sinceDate || 'Apr 15, 2026');
  const [weeklyInterval, setWeeklyInterval] = React.useState(initialGroup?.weeklyInterval || '1');
  const [weeklyDow, setWeeklyDow] = React.useState(initialGroup?.weeklyDow || 'WED');
  const [weeklyTime, setWeeklyTime] = React.useState(initialGroup?.weeklyTime || '13:30');
  const [dailyInterval, setDailyInterval] = React.useState(initialGroup?.dailyInterval || '1');
  const [dailyTimes, setDailyTimes] = React.useState(initialGroup?.dailyTimes || ['08:00', '20:00']);
  const [meds, setMeds] = React.useState(initialGroup?.meds || [
    { id: 'm1', name: 'Estradiol valerate', dose: '5.0', route: 'IM' },
  ]);
  const [editingMed, setEditingMed] = React.useState(null);
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  const addTime = () => setDailyTimes(t => [...t, '09:00']);
  const removeTime = (i) => setDailyTimes(t => t.filter((_, j) => j !== i));
  const updateTime = (i, v) => setDailyTimes(t => t.map((x, j) => j === i ? v : x));

  const addMed = () => setEditingMed({ id: null, name: '', dose: '', route: 'Oral' });
  const editMed = (m) => setEditingMed({ ...m });
  const removeMed = (id) => setMeds(list => list.filter(m => m.id !== id));
  const saveMed = (m) => {
    setMeds(list => {
      if (!m.id) return [...list, { ...m, id: `m${Date.now()}` }];
      return list.map(x => x.id === m.id ? m : x);
    });
    setEditingMed(null);
  };

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      background: HRT.surface, fontFamily: HRT_FONT,
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Top app bar with back / title / save */}
      <div style={{
        height: 64, display: 'flex', alignItems: 'center', padding: '0 4px',
        background: scrolled ? HRT.surfaceContainer : HRT.surface,
        transition: 'background-color 200ms',
        flexShrink: 0, zIndex: 5, gap: 4,
      }}>
        <IconButton icon="arrow_back" onClick={onBack} />
        <div style={{ flex: 1, fontSize: 20, fontWeight: 500, color: HRT.onSurface, letterSpacing: 0 }}>
          {isEditing ? 'Edit group' : 'New group'}
        </div>
        <Pressable onClick={() => onSave({ name, scheduleType, sinceDate, weeklyInterval, weeklyDow, weeklyTime, dailyInterval, dailyTimes, meds })} style={{
          padding: '10px 20px', borderRadius: 9999,
          background: name && meds.length ? HRT.primary : HRT.surfaceContainerHigh,
          color: name && meds.length ? HRT.onPrimary : HRT.outline,
          fontSize: 14, fontWeight: 600, letterSpacing: 0.1,
          marginRight: 8,
        }}>
          Save
        </Pressable>
      </div>

      <div onScroll={(e) => setScrolled(e.target.scrollTop > 4)}
           style={{ flex: 1, overflowY: 'auto', padding: '0 16px 80px' }}>

        {/* Group name */}
        <div style={{ marginTop: 12 }}>
          <TextField label="Group name" value={name} onChange={setName} />
        </div>

        {/* Schedule */}
        <SectionHeader title="Schedule" />
        <Segmented
          options={[{ label: 'Weekly', value: 'weekly' }, { label: 'Daily', value: 'daily' }]}
          value={scheduleType} onChange={setScheduleType}
        />

        <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <FieldRow label="Start date" value={sinceDate} icon="event" trailing={
            <Icon name="chevron_right" size={20} color={HRT.onSurfaceVariant} />
          } />

          {scheduleType === 'weekly' ? (
            <WeeklyBody
              interval={weeklyInterval} onIntervalChange={setWeeklyInterval}
              dow={weeklyDow} onDowChange={setWeeklyDow}
              time={weeklyTime} onTimeChange={setWeeklyTime}
            />
          ) : (
            <DailyBody
              interval={dailyInterval} onIntervalChange={setDailyInterval}
              times={dailyTimes} onAdd={addTime} onRemove={removeTime} onChange={updateTime}
            />
          )}
        </div>

        {/* Medications */}
        <SectionHeader title="Medications" trailing={
          <Pressable onClick={addMed} style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: '6px 12px 6px 8px', borderRadius: 9999,
            background: HRT.primaryContainer, color: HRT.onPrimaryContainer,
            fontSize: 13, fontWeight: 600, letterSpacing: 0.1,
          }}>
            <Icon name="add" size={18} fill={1} />
            Add
          </Pressable>
        } />

        {meds.length === 0 ? (
          <div style={{
            padding: '24px 16px', borderRadius: 16,
            background: HRT.surfaceContainerLow, border: `1px dashed ${HRT.outlineVariant}`,
            textAlign: 'center', color: HRT.onSurfaceVariant, fontSize: 14,
          }}>
            No medications in this group yet.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {meds.map(m => (
              <MedicationRow key={m.id} med={m} onEdit={() => editMed(m)} onRemove={() => removeMed(m.id)} />
            ))}
          </div>
        )}

        {/* Danger zone */}
        {isEditing && (
          <>
            <SectionHeader title="Danger zone" />
            <Pressable onClick={() => setConfirmDelete(true)} style={{
              display: 'flex', alignItems: 'center', gap: 12, width: '100%',
              padding: '14px 16px', borderRadius: 16,
              background: HRT.errorContainer, color: HRT.onErrorContainer,
              fontSize: 15, fontWeight: 500,
            }}>
              <Icon name="delete" size={20} fill={0} />
              <span style={{ flex: 1, textAlign: 'left' }}>Delete group</span>
              <Icon name="chevron_right" size={20} />
            </Pressable>
          </>
        )}
      </div>

      {/* Medication editor bottom sheet */}
      {editingMed && (
        <MedicationEditorSheet
          med={editingMed}
          onClose={() => setEditingMed(null)}
          onSave={saveMed}
        />
      )}

      {/* Delete confirmation */}
      {confirmDelete && (
        <ConfirmDialog
          title="Delete this group?"
          body="All schedule rules for this group will be removed. Past log entries stay."
          confirmLabel="Delete"
          danger
          onCancel={() => setConfirmDelete(false)}
          onConfirm={() => { setConfirmDelete(false); onDelete && onDelete(); }}
        />
      )}
    </div>
  );
}

function WeeklyBody({ interval, onIntervalChange, dow, onDowChange, time, onTimeChange }) {
  const DOWS = [
    { v: 'MON', l: 'M' }, { v: 'TUE', l: 'T' }, { v: 'WED', l: 'W' },
    { v: 'THU', l: 'T' }, { v: 'FRI', l: 'F' }, { v: 'SAT', l: 'S' }, { v: 'SUN', l: 'S' },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <TextField label="Every N weeks" value={interval} onChange={onIntervalChange} suffix="weeks" type="number" />
      <div style={{ padding: '12px 16px', borderRadius: 16, background: HRT.surfaceContainerLow, border: `1px solid ${HRT.outlineVariant}` }}>
        <div style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase', marginBottom: 8 }}>
          Day of week
        </div>
        <div style={{ display: 'flex', gap: 4, justifyContent: 'space-between' }}>
          {DOWS.map(d => {
            const sel = dow === d.v;
            return (
              <button key={d.v} onClick={() => onDowChange(d.v)} style={{
                width: 36, height: 36, borderRadius: 18,
                background: sel ? HRT.primary : 'transparent',
                color: sel ? HRT.onPrimary : HRT.onSurface,
                border: sel ? 'none' : `1px solid ${HRT.outline}`,
                fontSize: 14, fontWeight: sel ? 700 : 500, fontFamily: HRT_FONT, cursor: 'pointer',
              }}>{d.l}</button>
            );
          })}
        </div>
      </div>
      <FieldRow label="Time" value={time} icon="schedule" trailing={
        <Icon name="chevron_right" size={20} color={HRT.onSurfaceVariant} />
      } />
    </div>
  );
}

function DailyBody({ interval, onIntervalChange, times, onAdd, onRemove, onChange }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <TextField label="Every N days" value={interval} onChange={onIntervalChange} suffix="days" type="number" />
      <div style={{ padding: '12px 16px 8px', borderRadius: 16, background: HRT.surfaceContainerLow, border: `1px solid ${HRT.outlineVariant}` }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: 8,
        }}>
          <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase' }}>
            Times of day · {times.length}
          </span>
          <Pressable onClick={onAdd} style={{
            padding: '4px 10px 4px 6px', borderRadius: 9999,
            background: HRT.secondaryContainer, color: HRT.onSecondaryContainer,
            fontSize: 12, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 3,
          }}>
            <Icon name="add" size={16} fill={1} /> Add time
          </Pressable>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {times.map((t, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '8px 4px 8px 10px',
              background: HRT.surface, borderRadius: 12,
            }}>
              <Icon name="schedule" size={18} color={HRT.onSurfaceVariant} fill={0} />
              <span style={{ flex: 1, fontSize: 16, fontWeight: 500, color: HRT.onSurface, fontVariantNumeric: 'tabular-nums' }}>
                {t}
              </span>
              <IconButton icon="delete" onClick={() => onRemove(i)} size={36} iconSize={20} color={HRT.error} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MedicationRow({ med, onEdit, onRemove }) {
  const routeLabel = med.route === 'IM' ? 'IM' : med.route === 'Oral' ? 'Oral' : med.route;
  const routeColor = med.route === 'IM' ? HRT.primaryContainer : HRT.tertiaryContainer;
  const routeFg = med.route === 'IM' ? HRT.onPrimaryContainer : HRT.onTertiaryContainer;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 8px 12px 14px', borderRadius: 16,
      background: HRT.surfaceContainerLow, border: `1px solid ${HRT.outlineVariant}`,
    }}>
      <div style={{
        padding: '3px 8px', borderRadius: 6,
        background: routeColor, color: routeFg,
        fontSize: 10, fontWeight: 700, letterSpacing: 0.4, flexShrink: 0,
      }}>{routeLabel}</div>
      <Pressable onClick={onEdit} style={{ flex: 1, textAlign: 'left', padding: 0, background: 'transparent' }}>
        <div style={{ fontSize: 15, fontWeight: 500, color: HRT.onSurface, lineHeight: '20px' }}>{med.name}</div>
        <div style={{ fontSize: 13, color: HRT.onSurfaceVariant, marginTop: 1, fontVariantNumeric: 'tabular-nums' }}>
          {med.dose} mg
        </div>
      </Pressable>
      <IconButton icon="edit" onClick={onEdit} size={36} iconSize={18} />
      <IconButton icon="close" onClick={onRemove} size={36} iconSize={20} />
    </div>
  );
}

// ---------- Medication Editor (bottom sheet) ----------
function MedicationEditorSheet({ med, onClose, onSave }) {
  const [name, setName] = React.useState(med.name || '');
  const [dose, setDose] = React.useState(med.dose || '');
  const [route, setRoute] = React.useState(med.route || 'Oral');
  const isEdit = !!med.id;
  const valid = name.trim() && parseFloat(dose) > 0;

  const ROUTES = [
    { v: 'Oral', label: 'Oral', icon: 'medication' },
    { v: 'IM', label: 'Intramuscular', icon: 'vaccines' },
    { v: 'Subcutaneous', label: 'Subcutaneous', icon: 'colorize' },
    { v: 'Transdermal', label: 'Transdermal', icon: 'bandage' },
    { v: 'Sublingual', label: 'Sublingual', icon: 'favorite' },
    { v: 'Other', label: 'Other', icon: 'more_horiz' },
  ];

  return (
    <div style={{
      position: 'absolute', inset: 0, background: HRT.scrim,
      display: 'flex', alignItems: 'flex-end', zIndex: 20,
      fontFamily: HRT_FONT, animation: 'fadeIn 150ms',
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: '100%', background: HRT.surfaceContainerLow,
        borderRadius: '28px 28px 0 0', padding: '0 16px 16px',
        maxHeight: '92%', display: 'flex', flexDirection: 'column',
      }}>
        {/* drag handle */}
        <div style={{ width: 32, height: 4, borderRadius: 2, background: HRT.onSurfaceVariant, opacity: 0.4, margin: '12px auto 4px' }} />
        {/* title row */}
        <div style={{ display: 'flex', alignItems: 'center', padding: '8px 4px 12px' }}>
          <IconButton icon="close" onClick={onClose} />
          <div style={{ flex: 1, fontSize: 20, fontWeight: 500, color: HRT.onSurface, paddingLeft: 8 }}>
            {isEdit ? 'Edit medication' : 'Add medication'}
          </div>
          <Pressable onClick={() => valid && onSave({ ...med, name: name.trim(), dose, route })} style={{
            padding: '10px 20px', borderRadius: 9999,
            background: valid ? HRT.primary : HRT.surfaceContainerHigh,
            color: valid ? HRT.onPrimary : HRT.outline,
            fontSize: 14, fontWeight: 600, letterSpacing: 0.1,
          }}>Save</Pressable>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, padding: '4px 0 8px' }}>
          {/* Route as chips */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase', marginBottom: 8, paddingLeft: 4 }}>
              Route of administration
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {ROUTES.map(r => (
                <Chip key={r.v} label={r.label} selected={route === r.v} onClick={() => setRoute(r.v)} />
              ))}
            </div>
          </div>

          <TextField label="Medicine name" value={name} onChange={setName} />
          <TextField label="Dosage" value={dose} onChange={setDose} suffix="mg (as medicine)" type="number" />

          {/* Summary preview */}
          {valid && (
            <div style={{
              padding: '14px 16px', borderRadius: 16,
              background: HRT.primaryContainer, color: HRT.onPrimaryContainer,
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: 12,
                background: 'rgba(255,255,255,0.55)', display: 'flex',
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name={ROUTES.find(r => r.v === route)?.icon || 'medication'} size={22} fill={1} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.5, textTransform: 'uppercase', opacity: 0.8 }}>
                  Preview
                </div>
                <div style={{ fontSize: 15, fontWeight: 600, marginTop: 2 }}>
                  {name} · {dose} mg
                </div>
                <div style={{ fontSize: 12, opacity: 0.8 }}>
                  {ROUTES.find(r => r.v === route)?.label}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ConfirmDialog({ title, body, confirmLabel, danger, onCancel, onConfirm }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, background: HRT.scrim,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24, zIndex: 30, fontFamily: HRT_FONT,
    }} onClick={onCancel}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: HRT.surfaceContainerHigh, borderRadius: 28,
        padding: 24, maxWidth: 320, width: '100%',
        boxShadow: '0 10px 30px rgba(0,0,0,.25)',
      }}>
        <div style={{ fontSize: 22, fontWeight: 500, color: HRT.onSurface, letterSpacing: 0, marginBottom: 12 }}>
          {title}
        </div>
        <div style={{ fontSize: 14, lineHeight: '20px', color: HRT.onSurfaceVariant, marginBottom: 20, letterSpacing: 0.25 }}>
          {body}
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <Pressable onClick={onCancel} style={{
            padding: '10px 16px', borderRadius: 9999,
            color: HRT.primary, fontSize: 14, fontWeight: 600,
          }}>Cancel</Pressable>
          <Pressable onClick={onConfirm} style={{
            padding: '10px 20px', borderRadius: 9999,
            background: danger ? HRT.error : HRT.primary,
            color: danger ? HRT.onPrimary : HRT.onPrimary,
            fontSize: 14, fontWeight: 600,
          }}>{confirmLabel}</Pressable>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GroupEditorScreen, MedicationEditorSheet, ConfirmDialog });
