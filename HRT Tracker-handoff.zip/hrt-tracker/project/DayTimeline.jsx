// DayTimeline — vertical time-of-day timeline showing scheduled + actual doses
function DayTimeline({ selectedDate, records }) {
  const isToday = isSameDay(selectedDate, PLAN_DATA.today);
  const nowHour = 11.25; // 11:15 "now" marker for today

  // Timeline spans 6am → midnight (18 hours)
  const startH = 6, endH = 24;
  const hourToY = (h) => ((h - startH) / (endH - startH)) * 100;

  // Time-of-day bands for background
  const bands = [
    { label: 'Morning', from: 6, to: 12, color: 'rgba(141, 73, 89, 0.04)' },
    { label: 'Afternoon', from: 12, to: 17, color: 'rgba(122, 87, 50, 0.04)' },
    { label: 'Evening', from: 17, to: 22, color: 'rgba(91, 63, 68, 0.05)' },
    { label: 'Night', from: 22, to: 24, color: 'rgba(34, 25, 27, 0.05)' },
  ];
  const hourMarks = [6, 9, 12, 15, 18, 21];

  return (
    <div style={{ padding: '8px 16px 4px', fontFamily: HRT_FONT }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '4px 4px 8px' }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 500, color: HRT.onSurface, letterSpacing: 0 }}>
            {selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
          </div>
          <div style={{ fontSize: 13, color: HRT.onSurfaceVariant, marginTop: 2 }}>
            {records.length === 0 ? 'No doses planned' : `${records.length} ${records.length === 1 ? 'dose' : 'doses'}`}
          </div>
        </div>
        {isToday && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: '4px 10px', borderRadius: 9999,
            background: HRT.secondaryContainer, color: HRT.onSecondaryContainer,
            fontSize: 12, fontWeight: 600, letterSpacing: 0.2,
          }}>
            Today
          </div>
        )}
      </div>

      {records.length === 0 ? (
        <div style={{
          padding: '32px 16px', textAlign: 'center',
          color: HRT.onSurfaceVariant, fontSize: 14,
        }}>
          No records for this day.
        </div>
      ) : (
        <div style={{ position: 'relative', minHeight: 380, padding: '8px 0' }}>
          {/* band backgrounds */}
          <div style={{ position: 'absolute', left: 52, right: 0, top: 8, bottom: 8, borderRadius: 20, overflow: 'hidden' }}>
            {bands.map((b, i) => (
              <div key={i} style={{
                position: 'absolute', left: 0, right: 0,
                top: `${hourToY(b.from)}%`, height: `${hourToY(b.to) - hourToY(b.from)}%`,
                background: b.color,
              }} />
            ))}
          </div>

          {/* hour gridlines + labels */}
          {hourMarks.map(h => (
            <React.Fragment key={h}>
              <div style={{
                position: 'absolute', left: 52, right: 12,
                top: `calc(${hourToY(h)}% + 8px)`, height: 1,
                background: HRT.outlineVariant, opacity: 0.5,
              }} />
              <div style={{
                position: 'absolute', left: 0, width: 44,
                top: `calc(${hourToY(h)}% + 8px)`, transform: 'translateY(-50%)',
                textAlign: 'right', fontSize: 11, color: HRT.onSurfaceVariant,
                fontVariantNumeric: 'tabular-nums', letterSpacing: 0.2,
              }}>
                {h.toString().padStart(2,'0')}:00
              </div>
            </React.Fragment>
          ))}

          {/* now marker */}
          {isToday && (
            <div style={{
              position: 'absolute', left: 44, right: 8,
              top: `calc(${hourToY(nowHour)}% + 8px)`, height: 0,
            }}>
              <div style={{
                position: 'absolute', left: 0, right: 0, height: 2,
                background: HRT.primary, borderRadius: 1,
              }} />
              <div style={{
                position: 'absolute', left: -4, top: -4, width: 10, height: 10,
                borderRadius: 5, background: HRT.primary,
                boxShadow: `0 0 0 3px ${HRT.primaryContainer}`,
              }} />
              <div style={{
                position: 'absolute', right: 0, top: -11,
                padding: '2px 8px', borderRadius: 9999,
                background: HRT.primary, color: HRT.onPrimary,
                fontSize: 11, fontWeight: 600, letterSpacing: 0.2,
              }}>Now</div>
            </div>
          )}

          {/* dose markers */}
          {records.map((r, i) => {
            const [hh, mm] = r.scheduledTime.split(':').map(Number);
            const h = hh + mm/60;
            return (
              <DoseMarker
                key={r.id}
                record={r}
                top={`calc(${hourToY(h)}% + 8px)`}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}

function DoseMarker({ record, top }) {
  const st = record.status;
  const done = st === 'done';
  const dueSoon = st === 'due-soon';
  const missed = st === 'missed';
  const upcoming = st === 'upcoming';

  // left: the dot. right: the card.
  const dotColor = done ? HRT.statusFulfilled
    : dueSoon ? HRT.primary
    : missed ? HRT.statusOverdue
    : HRT.outline;

  const cardBg = done ? HRT.surfaceContainer
    : dueSoon ? HRT.primaryContainer
    : missed ? HRT.errorContainer
    : HRT.surfaceContainerLow;
  const cardFg = done ? HRT.onSurface
    : dueSoon ? HRT.onPrimaryContainer
    : missed ? HRT.onErrorContainer
    : HRT.onSurface;

  const routeIcon = record.route === 'Intramuscular' ? 'vaccines'
    : record.route === 'Oral' ? 'medication'
    : 'medication';

  return (
    <div style={{ position: 'absolute', left: 52, right: 12, top, transform: 'translateY(-50%)' }}>
      {/* dot */}
      <div style={{
        position: 'absolute', left: -28, top: '50%', transform: 'translateY(-50%)',
        width: 14, height: 14, borderRadius: 7,
        background: done ? dotColor : HRT.surface,
        border: `2px solid ${dotColor}`,
        boxSizing: 'border-box',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {done && <Icon name="check" size={10} color={HRT.onPrimary} weight={700} fill={1} />}
      </div>

      {/* card */}
      <div style={{
        background: cardBg, color: cardFg,
        borderRadius: 16, padding: '10px 14px',
        display: 'flex', alignItems: 'center', gap: 12,
        fontFamily: HRT_FONT,
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: done ? HRT.surfaceContainerHigh : 'rgba(255,255,255,0.4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: cardFg, flexShrink: 0,
        }}>
          <Icon name={routeIcon} size={20} fill={1} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 500, lineHeight: '20px' }}>
            {record.name}
          </div>
          <div style={{ fontSize: 12, color: done ? HRT.onSurfaceVariant : cardFg, opacity: done ? 1 : 0.8, marginTop: 1 }}>
            {record.dose} {record.unit} · {record.route}
          </div>
        </div>
        <div style={{
          fontSize: 14, fontWeight: 500, letterSpacing: 0.2,
          fontVariantNumeric: 'tabular-nums', textAlign: 'right',
        }}>
          <div>{record.scheduledTime}</div>
          <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: 0.5, textTransform: 'uppercase', opacity: 0.75 }}>
            {done ? 'Done' : dueSoon ? 'Due' : missed ? 'Missed' : 'Next'}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DayTimeline });
