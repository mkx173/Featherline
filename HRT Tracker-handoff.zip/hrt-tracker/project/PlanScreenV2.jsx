// PlanScreenV2 — scoped: 3-week strip, flat day list, regimen focus, history top-right
// Now includes navigation to the GroupEditor screen when a group is tapped.
function PlanScreenV2({ onOpenHistory }) {
  const [selectedDate, setSelectedDate] = React.useState(PLAN_DATA.today);
  const [scrolled, setScrolled] = React.useState(false);
  const [editingGroupId, setEditingGroupId] = React.useState(null); // null | 'new' | groupId
  const records = isSameDay(selectedDate, PLAN_DATA.today) ? PLAN_DATA.todaysRecords : [];

  // resolve the initial group for the editor
  const editingGroup = React.useMemo(() => {
    if (!editingGroupId || editingGroupId === 'new') return null;
    const g = PLAN_DATA.groups.find(x => x.id === editingGroupId);
    if (!g) return null;
    // translate to editor shape
    const isWeekly = g.cadence.startsWith('Every Wed');
    return {
      id: g.id,
      name: g.name,
      scheduleType: isWeekly ? 'weekly' : 'daily',
      sinceDate: 'Apr 15, 2026',
      weeklyInterval: '1',
      weeklyDow: 'WED',
      weeklyTime: isWeekly ? g.time : '13:30',
      dailyInterval: '1',
      dailyTimes: !isWeekly ? g.time.split(' · ') : ['08:00', '20:00'],
      meds: g.meds.map((m, i) => ({
        id: `m${i}`,
        name: m.name,
        dose: String(parseFloat(m.dose)),
        route: m.route === 'Intramuscular' ? 'IM' : m.route,
      })),
    };
  }, [editingGroupId]);

  if (editingGroupId) {
    return (
      <GroupEditorScreen
        initialGroup={editingGroup}
        onBack={() => setEditingGroupId(null)}
        onSave={() => setEditingGroupId(null)}
        onDelete={() => setEditingGroupId(null)}
      />
    );
  }

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      background: HRT.surface, fontFamily: HRT_FONT,
      position: 'relative', overflow: 'hidden',
    }}>
      <TopBar
        title="Plan"
        scrolled={scrolled}
        trailing={<>
          <IconButton icon="bar_chart" onClick={onOpenHistory} />
          <IconButton icon="more_vert" />
        </>}
      />

      <div
        onScroll={(e) => setScrolled(e.target.scrollTop > 4)}
        style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}
      >
        <ThreeWeekStrip selectedDate={selectedDate} onSelect={setSelectedDate} />
        <div style={{ height: 1, background: HRT.outlineVariant, margin: '4px 16px 0', opacity: 0.5 }} />
        <DayRecordList selectedDate={selectedDate} records={records} />
        <div style={{ height: 8 }} />
        <RegimenSection onEdit={(id) => setEditingGroupId(id)} />
        <div style={{ height: 80 }} />
      </div>

      <div style={{ position: 'absolute', right: 16, bottom: 16 }}>
        <FAB icon="add" label="New group" extended variant="primary" onClick={() => setEditingGroupId('new')} />
      </div>
    </div>
  );
}

Object.assign(window, { PlanScreenV2 });
