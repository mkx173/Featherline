// PlanScreen — the main screen
function PlanScreen({ tweaks, onEdit }) {
  const [selectedDate, setSelectedDate] = React.useState(PLAN_DATA.today);
  const [scrolled, setScrolled] = React.useState(false);
  const records = isSameDay(selectedDate, PLAN_DATA.today) ? PLAN_DATA.todaysRecords : [];

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      background: HRT.surface, fontFamily: HRT_FONT,
      position: 'relative', overflow: 'hidden',
    }}>
      <TopBar
        title="Plan"
        scrolled={scrolled}
        trailing={<>
          <IconButton icon="insights" />
          <IconButton icon="more_vert" />
        </>}
      />

      <div
        onScroll={(e) => setScrolled(e.target.scrollTop > 4)}
        style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}
      >
        {tweaks.hero !== 'none' && <AdherenceHero variant={tweaks.hero} />}
        <WeekStrip selectedDate={selectedDate} onSelect={setSelectedDate} />
        {tweaks.divider && (
          <div style={{ height: 1, background: HRT.outlineVariant, margin: '0 16px', opacity: 0.6 }} />
        )}
        <DayTimeline selectedDate={selectedDate} records={records} />
        <GroupsSection onEdit={onEdit} />
        <div style={{ height: 80 }} />
      </div>

      {/* FAB stack */}
      <div style={{
        position: 'absolute', right: 16, bottom: 16,
        display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'flex-end',
      }}>
        {tweaks.fabExtended
          ? <FAB icon="add" label="New group" extended variant="primary" />
          : <FAB icon="add" variant="primary" />}
      </div>
    </div>
  );
}

Object.assign(window, { PlanScreen });
