// HISTORY_DATA — 3 months of mock medication log entries (Feb, Mar, Apr 2026)
// Pattern: Daily spironolactone 100mg @ 08:00 and 20:00. Weekly estradiol valerate 5mg IM on Wednesdays @ 13:30.
// Mixed sources (group_schedule, group_manual, manual), realistic adherence (mostly on-track with a few gaps).
// "Today" = Wed Apr 22, 2026, 11:15 — meaning today's 13:30 E2 and 20:00 spiro are future.

const HISTORY_DATA = (() => {
  const TODAY = new Date(2026, 3, 22, 11, 15);

  // helper
  const d = (y, mo, day, h, m) => new Date(y, mo, day, h, m, 0, 0);
  const key = (date) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;

  const entries = []; // { id, date, time: 'HH:MM', name, dose, unit, route, source, group, dosageMg, dosageE2 }

  let idSeq = 1;
  const add = (date, name, dose, route, source, group, adjustMin = 0) => {
    const when = new Date(+date + adjustMin * 60 * 1000);
    entries.push({
      id: `e${idSeq++}`,
      when,
      name,
      dose,
      unit: 'mg',
      route,
      source, // 'group_schedule' | 'group_manual' | 'manual'
      group,
      dosageE2: name === 'Estradiol valerate' ? dose * 0.764 : dose, // rough EV → E2 ratio
    });
  };

  // Generate across Feb 1 – Apr 22
  const start = new Date(2026, 1, 1); // Feb 1
  for (let cur = new Date(start); cur <= TODAY; cur.setDate(cur.getDate() + 1)) {
    const date = new Date(cur);
    const dow = date.getDay(); // 0=Sun … 3=Wed
    const isWed = dow === 3;
    const isFuture = date > TODAY;
    if (isFuture) break;

    const isToday = date.toDateString() === TODAY.toDateString();
    const ymdKey = key(date);

    // deterministic "missed" days (pseudo-random based on day number for realism)
    const daySeed = date.getDate() + date.getMonth() * 31;
    const pRand = (Math.sin(daySeed * 99173.3) + 1) / 2; // 0..1

    // DAILY SPIRO — morning 08:00
    // today: morning dose done at 08:04, evening skipped (future)
    if (isToday) {
      add(d(2026, 3, 22, 8, 4), 'Spironolactone', 100, 'Oral', 'group_schedule', 'Daily spironolactone', 0);
    } else {
      // miss morning on ~5% of past days
      if (pRand > 0.06) {
        const offsetMin = Math.round((pRand - 0.5) * 30); // ±15 min jitter
        add(d(date.getFullYear(), date.getMonth(), date.getDate(), 8, 0), 'Spironolactone', 100, 'Oral',
            offsetMin === 0 ? 'group_schedule' : 'group_manual', 'Daily spironolactone', offsetMin);
      }
    }

    // DAILY SPIRO — evening 20:00 (past days only, not today)
    if (!isToday) {
      const pRand2 = (Math.sin(daySeed * 71717.7) + 1) / 2;
      if (pRand2 > 0.08) {
        const offsetMin = Math.round((pRand2 - 0.5) * 40);
        add(d(date.getFullYear(), date.getMonth(), date.getDate(), 20, 0), 'Spironolactone', 100, 'Oral',
            Math.abs(offsetMin) < 5 ? 'group_schedule' : 'group_manual', 'Daily spironolactone', offsetMin);
      }
    }

    // WEEKLY E2 IM — Wednesdays @ 13:30 (past Wednesdays)
    if (isWed && !isToday) {
      const pRand3 = (Math.sin(daySeed * 41117.1) + 1) / 2;
      if (pRand3 > 0.08) {
        const offsetMin = Math.round((pRand3 - 0.5) * 120); // ±60 min
        add(d(date.getFullYear(), date.getMonth(), date.getDate(), 13, 30), 'Estradiol valerate', 5.0, 'IM',
            offsetMin === 0 ? 'group_schedule' : 'group_manual', 'Weekly estradiol IM', offsetMin);
      }
    }
  }

  // A few manual / off-schedule entries (unplanned)
  add(d(2026, 1, 14, 21, 45), 'Progesterone', 100, 'Oral', 'manual', null); // Feb 14 late
  add(d(2026, 2, 7, 18, 12), 'Progesterone', 100, 'SL', 'manual', null);     // Mar 7
  add(d(2026, 2, 28, 10, 30), 'Estradiol valerate', 2.5, 'IM', 'manual', null); // Mar 28 top-up
  add(d(2026, 3, 5, 9, 0), 'Progesterone', 100, 'Oral', 'manual', null);     // Apr 5

  // Day status map, computed like PlanCalendarDayStatus:
  //   expected occurrences per day = 2 (spiro × 2) + (Wed ? 1 : 0) for the E2 IM
  //   matched occurrences = group-sourced entries for that day (capped)
  //   past day + matched < expected → overdue/partial; future/today evening pending → NONE/partial
  const dayStatus = {};
  const entriesByDay = {};
  for (const e of entries) {
    const k = key(e.when);
    if (!entriesByDay[k]) entriesByDay[k] = [];
    entriesByDay[k].push(e);
  }

  // span: from the earliest month (Feb 2026) to May 2026 (one future month visible)
  const spanStart = new Date(2026, 1, 1);
  const spanEnd = new Date(2026, 4, 31);
  for (let cur = new Date(spanStart); cur <= spanEnd; cur.setDate(cur.getDate() + 1)) {
    const date = new Date(cur);
    const isFuture = date > TODAY;
    const isToday = date.toDateString() === TODAY.toDateString();
    const k = key(date);
    const dow = date.getDay();
    const isWed = dow === 3;
    const expected = 2 + (isWed ? 1 : 0);
    const list = entriesByDay[k] || [];
    const groupMatched = list.filter(x => x.source === 'group_schedule' || x.source === 'group_manual').length;
    const hasManualOnly = list.length > 0 && groupMatched === 0;

    let status;
    if (isFuture) {
      status = 'future';
    } else if (isToday) {
      // expected 3 today (wed), matched so far = 1 (morning spiro) → partial
      status = groupMatched >= expected ? 'fulfilled' : groupMatched > 0 ? 'partial' : (expected === 0 ? 'none' : 'scheduled');
    } else if (expected === 0 && hasManualOnly) {
      status = 'unplanned';
    } else if (expected === 0) {
      status = 'none';
    } else if (groupMatched === 0) {
      status = 'overdue';
    } else if (groupMatched < expected) {
      status = 'partial';
    } else {
      status = 'fulfilled';
    }
    dayStatus[k] = { status, expected, matched: Math.min(groupMatched, expected), entryCount: list.length };
  }

  // Sort entries descending by time
  entries.sort((a, b) => b.when - a.when);

  // Month summary for any YYYY-MM
  function summaryForMonth(year, month0) {
    let logged = 0, onTrack = 0, partial = 0, missed = 0;
    for (const k of Object.keys(dayStatus)) {
      const [y, m] = k.split('-').map(Number);
      if (y !== year || m - 1 !== month0) continue;
      const s = dayStatus[k].status;
      if (s === 'fulfilled') onTrack++;
      else if (s === 'partial') partial++;
      else if (s === 'overdue') missed++;
    }
    for (const e of entries) {
      if (e.when.getFullYear() === year && e.when.getMonth() === month0) logged++;
    }
    return { logged, onTrack, partial, missed };
  }

  function entriesForMonth(year, month0) {
    return entries.filter(e => e.when.getFullYear() === year && e.when.getMonth() === month0);
  }

  function entriesForDay(dateKey) {
    return entries.filter(e => key(e.when) === dateKey);
  }

  return {
    TODAY,
    entries,
    dayStatus,
    summaryForMonth,
    entriesForMonth,
    entriesForDay,
    key,
  };
})();

Object.assign(window, { HISTORY_DATA });
