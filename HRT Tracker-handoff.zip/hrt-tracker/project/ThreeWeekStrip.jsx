// ThreeWeekStrip — horizontally-paged week strip limited to prev/current/next
function ThreeWeekStrip({ selectedDate, onSelect }) {
  const [page, setPage] = React.useState(1); // 0=prev, 1=current, 2=next
  const today = PLAN_DATA.today;
  const weeks = React.useMemo(() => [
    buildWeekStrip(today, -1),
    buildWeekStrip(today, 0),
    buildWeekStrip(today, 1),
  ], []);
  const days = weeks[page];
  const headerDate = days[3];
  const label = monthName(headerDate);
  const pageLabels = ['Last week', 'This week', 'Next week'];

  const goPrev = () => setPage(p => Math.max(0, p - 1));
  const goNext = () => setPage(p => Math.min(2, p + 1));

  return (
    <div style={{ fontFamily: HRT_FONT, padding: '0 4px' }}>
      {/* month + week context */}
      <div style={{ display: 'flex', alignItems: 'center', padding: '4px 4px 0', gap: 4 }}>
        <IconButton icon="chevron_left" onClick={goPrev} />
        <div style={{ flex: 1, textAlign: 'center', lineHeight: 1.15 }}>
          <div style={{ fontSize: 15, fontWeight: 600, color: HRT.onSurface, letterSpacing: 0.1 }}>{label}</div>
          <div style={{ fontSize: 11, fontWeight: 500, letterSpacing: 0.5, color: HRT.onSurfaceVariant, textTransform: 'uppercase', marginTop: 2 }}>
            {pageLabels[page]}
          </div>
        </div>
        <IconButton icon="chevron_right" onClick={goNext} />
      </div>

      {/* pagination pips */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 6, padding: '6px 0 2px' }}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            width: i === page ? 18 : 6, height: 6, borderRadius: 3,
            background: i === page ? HRT.primary : HRT.outlineVariant,
            transition: 'width 200ms, background 200ms',
          }} />
        ))}
      </div>

      {/* the strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2, padding: '8px 4px 12px' }}>
        {days.map((d, i) => {
          const isToday = isSameDay(d, today);
          const isSelected = isSameDay(d, selectedDate);
          const sameMonth = d.getMonth() === today.getMonth();
          const status = sameMonth ? PLAN_DATA.status(d.getDate()) : 'none';
          return <DayCell key={i} day={d} isToday={isToday} isSelected={isSelected} status={status} onClick={() => onSelect(d)} />;
        })}
      </div>
    </div>
  );
}

Object.assign(window, { ThreeWeekStrip });
