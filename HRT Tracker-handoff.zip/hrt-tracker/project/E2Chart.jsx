// 7-day E2 concentration chart with target range band + pulsing "now" dot
function E2Chart() {
  const { e2, now } = HOME_DATA;
  const samples = e2.samples;
  if (!samples.length) return null;

  const W = 320, H = 160;
  const padL = 32, padR = 16, padT = 14, padB = 22;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;

  // y scale: 0 → max-ish (round up to 50)
  const maxY = Math.max(350, Math.ceil(Math.max(...samples.map(s => s.c)) / 50) * 50);
  const minY = 0;
  const yScale = (v) => padT + innerH - ((v - minY) / (maxY - minY)) * innerH;

  // x scale: first sample → last sample (includes "now")
  const t0 = +samples[0].t, t1 = +samples[samples.length - 1].t;
  const xScale = (t) => padL + (((+t) - t0) / (t1 - t0)) * innerW;

  // smooth path (cardinal-ish via quadratic)
  const pts = samples.map(s => [xScale(s.t), yScale(s.c)]);
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
    const cx = (x0 + x1) / 2;
    d += ` Q ${cx} ${y0}, ${cx} ${(y0 + y1) / 2} T ${x1} ${y1}`;
  }
  // area path to baseline
  const areaD = d + ` L ${pts[pts.length - 1][0]} ${padT + innerH} L ${pts[0][0]} ${padT + innerH} Z`;

  // target band
  const bandTop = yScale(e2.targetMax);
  const bandBot = yScale(e2.targetMin);

  // x-axis day ticks (every 24h from "now" back 7d, show day letters)
  const dayTicks = [];
  for (let offset = 6; offset >= 0; offset--) {
    const t = new Date(+now - offset * 24 * 60 * 60 * 1000);
    t.setHours(12, 0, 0, 0);
    if (+t < t0) continue;
    const x = xScale(t);
    const letter = ['S','M','T','W','T','F','S'][t.getDay()];
    dayTicks.push({ x, letter, isToday: offset === 0 });
  }

  // now point
  const nowPt = pts[pts.length - 1];

  const gradId = 'e2grad';

  return (
    <div style={{
      margin: '4px 16px 4px', padding: '16px 14px 10px',
      background: HRT.surfaceContainerLow, borderRadius: 28,
      fontFamily: HRT_FONT,
    }}>
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        padding: '0 6px 10px',
      }}>
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: 1,
          color: HRT.onSurfaceVariant, textTransform: 'uppercase',
        }}>7-day trend</div>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          fontSize: 11, color: HRT.onSurfaceVariant, letterSpacing: 0.2,
        }}>
          <span style={{
            display: 'inline-block', width: 14, height: 6, borderRadius: 2,
            background: HRT.tertiaryContainer, border: `1px solid ${HRT.tertiary}`,
            opacity: 0.7,
          }} />
          Target {e2.targetMin}–{e2.targetMax}
        </div>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block' }}>
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={HRT.primary} stopOpacity="0.35" />
            <stop offset="100%" stopColor={HRT.primary} stopOpacity="0" />
          </linearGradient>
          <filter id="nowglow">
            <feGaussianBlur stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Target range band */}
        <rect x={padL} y={bandTop} width={innerW} height={bandBot - bandTop}
          fill={HRT.tertiaryContainer} opacity="0.35" />
        <line x1={padL} y1={bandTop} x2={padL + innerW} y2={bandTop}
          stroke={HRT.tertiary} strokeWidth="1" strokeDasharray="3 3" opacity="0.55" />
        <line x1={padL} y1={bandBot} x2={padL + innerW} y2={bandBot}
          stroke={HRT.tertiary} strokeWidth="1" strokeDasharray="3 3" opacity="0.55" />

        {/* Y-axis labels */}
        {[100, 200, 300].map(v => (
          <text key={v} x={padL - 6} y={yScale(v) + 3}
            fontSize="9" fill={HRT.onSurfaceVariant} textAnchor="end"
            fontFamily={HRT_FONT} letterSpacing="0.3">{v}</text>
        ))}

        {/* area + line */}
        <path d={areaD} fill={`url(#${gradId})`} />
        <path d={d} fill="none" stroke={HRT.primary} strokeWidth="2.25"
          strokeLinecap="round" strokeLinejoin="round" />

        {/* X-axis day labels */}
        {dayTicks.map((t, i) => (
          <text key={i} x={t.x} y={H - 6}
            fontSize="10" fontWeight={t.isToday ? 700 : 500}
            fill={t.isToday ? HRT.primary : HRT.onSurfaceVariant}
            textAnchor="middle" fontFamily={HRT_FONT} letterSpacing="0.5">
            {t.letter}
          </text>
        ))}

        {/* "Now" pulsing dot */}
        <circle cx={nowPt[0]} cy={nowPt[1]} r="10"
          fill={HRT.primary} opacity="0.22">
          <animate attributeName="r" values="6;14;6" dur="1.8s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.35;0;0.35" dur="1.8s" repeatCount="indefinite" />
        </circle>
        <circle cx={nowPt[0]} cy={nowPt[1]} r="5"
          fill={HRT.primary} stroke={HRT.surfaceContainerLow} strokeWidth="2.5"
          filter="url(#nowglow)" />
      </svg>
    </div>
  );
}

Object.assign(window, { E2Chart });
