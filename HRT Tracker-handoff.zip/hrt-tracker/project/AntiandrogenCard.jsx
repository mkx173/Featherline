// Secondary antiandrogen card — Spironolactone last/next
function AntiandrogenCard() {
  const { antiandrogen: a } = HOME_DATA;
  return (
    <div style={{
      margin: '4px 16px', padding: '14px 18px',
      background: HRT.surfaceContainerLow, borderRadius: 24,
      display: 'flex', alignItems: 'center', gap: 14,
      fontFamily: HRT_FONT,
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: 14,
        background: HRT.secondaryContainer, color: HRT.onSecondaryContainer,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
      }}>
        <Icon name="medication" size={22} fill={1} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 10, fontWeight: 700, letterSpacing: 1,
          color: HRT.onSurfaceVariant, textTransform: 'uppercase',
        }}>Antiandrogen</div>
        <div style={{
          fontSize: 15, fontWeight: 600, color: HRT.onSurface,
          marginTop: 2, letterSpacing: 0.1,
        }}>{a.name} · 100 mg</div>
        <div style={{
          display: 'flex', gap: 10, alignItems: 'center', marginTop: 3,
          fontSize: 12, color: HRT.onSurfaceVariant, letterSpacing: 0.2,
        }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3 }}>
            <Icon name="check_circle" size={12} fill={1} color={HRT.statusFulfilled} />
            <span>{a.sinceSpiroLabel}</span>
          </span>
          <span style={{ opacity: 0.4 }}>·</span>
          <span>Next {a.nextDose.toLowerCase()}</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AntiandrogenCard });
