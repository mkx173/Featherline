// MonthCalendar — swipeable month grid with Plan-style status indicators
// Props: year, month0 (0-11), selectedKey ('YYYY-MM-DD' or null), onSelect, onPrev, onNext
function MonthCalendar({ year, month0, selectedKey, onSelect, onPrev, onNext, swipeable = true }) {
  const todayKey = HISTORY_DATA.key(HISTORY_DATA.TODAY);
  const firstDay = new Date(year, month0, 1);
  const daysInMonth = new Date(year, month0 + 1, 0).getDate();
  // Mon-first: shift so Mon=0
  const startOffset = (firstDay.getDay() + 6) % 7;
  const totalCells = Math.ceil((startOffset + daysInMonth) / 7) * 7;
  const cells = [];
  for (let i = 0; i < totalCells; i++) {
    const dayNum = i - startOffset + 1;
    if (dayNum >= 1 && dayNum <= daysInMonth) {
      const date = new Date(year, month0, dayNum);
      cells.push({ date, inMonth: true });
    } else {
      cells.push({ date: null, inMonth: false });
    }
  }

  // Swipe state
  const gripRef = React.useRef(null);
  const [dragX, setDragX] = React.useState(0);
  const dragStartX = React.useRef(null);
  const didSwipe = React.useRef(false);

  const onPointerDown = (e) => {
    if (!swipeable) return;
    dragStartX.current = e.clientX;
    didSwipe.current = false;
  };
  const onPointerMove = (e) => {
    if (dragStartX.current == null) return;
    const dx = e.clientX - dragStartX.current;
    setDragX(dx);
  };
  const onPointerUp = () => {
    if (dragStartX.current == null) return;
    if (Math.abs(dragX) > 60) {
      didSwipe.current = true;
      if (dragX > 0) onPrev && onPrev();
      else onNext && onNext();
    }
    dragStartX.current = null;
    setDragX(0);
  };

  const monthLabel = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div style={{ fontFamily: HRT_FONT, userSelect: 'none' }}>
      {/* Title + nav */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 4,
        padding: '8px 8px 4px',
      }}>
        <IconButton icon="chevron_left" onClick={onPrev} />
        <div style={{
          flex: 1, textAlign: 'center',
          fontSize: 18, fontWeight: 600, letterSpacing: 0,
          color: HRT.onSurface,
        }}>{monthLabel}</div>
        <IconButton icon="chevron_right" onClick={onNext} />
      </div>

      {/* Day-of-week row */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(7,1fr)',
        padding: '4px 16px 6px',
      }}>
        {['M','T','W','T','F','S','S'].map((d, i) => (
          <div key={i} style={{
            textAlign: 'center', fontSize: 11, fontWeight: 600, letterSpacing: 0.5,
            color: (i === 5 || i === 6) ? HRT.onSurfaceVariant : HRT.onSurfaceVariant,
            opacity: (i === 5 || i === 6) ? 0.7 : 1,
          }}>{d}</div>
        ))}
      </div>

      {/* Grid (swipeable) */}
      <div
        ref={gripRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
        style={{
          padding: '0 8px 8px',
          transform: `translateX(${dragX * 0.35}px)`,
          opacity: 1 - Math.min(Math.abs(dragX) / 400, 0.3),
          transition: dragStartX.current == null ? 'transform 200ms cubic-bezier(0.2,0,0,1), opacity 200ms' : 'none',
          touchAction: 'pan-y',
          cursor: swipeable ? 'grab' : 'default',
        }}
      >
        {Array.from({ length: cells.length / 7 }).map((_, w) => (
          <div key={w} style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)' }}>
            {cells.slice(w * 7, w * 7 + 7).map((c, i) => (
              <CalendarCell key={i}
                cell={c}
                todayKey={todayKey}
                selectedKey={selectedKey}
                onSelect={onSelect}
                isWeekend={i >= 5} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function CalendarCell({ cell, todayKey, selectedKey, onSelect, isWeekend }) {
  if (!cell.inMonth) return <div style={{ height: 48 }} />;
  const k = HISTORY_DATA.key(cell.date);
  const info = HISTORY_DATA.dayStatus[k] || { status: 'none' };
  const isToday = k === todayKey;
  const isSelected = k === selectedKey;
  const isFuture = info.status === 'future';

  const bg = isSelected ? HRT.primary
    : isToday ? HRT.secondaryContainer
    : 'transparent';
  const fg = isSelected ? HRT.onPrimary
    : isFuture ? `${HRT.onSurfaceVariant}80`
    : isToday ? HRT.onSecondaryContainer
    : HRT.onSurface;

  return (
    <Pressable onClick={() => onSelect(k)} style={{
      height: 48, borderRadius: 14,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 4, background: bg, color: fg,
      fontWeight: isToday || isSelected ? 700 : 500,
      opacity: isWeekend && !isSelected && !isToday ? 0.88 : 1,
    }}>
      <span style={{
        fontSize: 14, lineHeight: '18px',
        fontVariantNumeric: 'tabular-nums', letterSpacing: 0,
      }}>{cell.date.getDate()}</span>
      <DayStatusDot status={info.status} isSelected={isSelected} />
    </Pressable>
  );
}

// Same status dot system as the Plan screen
function DayStatusDot({ status, isSelected }) {
  const sz = 10;
  // when selected, use onPrimary for contrast
  const tint = isSelected ? HRT.onPrimary : null;

  if (status === 'fulfilled') {
    return (
      <Icon name="check" size={12}
        color={tint || HRT.statusFulfilled}
        weight={700} fill={0} />
    );
  }
  if (status === 'overdue') {
    return (
      <div style={{
        width: 8, height: 8, borderRadius: 4,
        border: `1.5px solid ${tint || HRT.statusOverdue}`,
        boxSizing: 'border-box',
      }} />
    );
  }
  if (status === 'partial') {
    return (
      <svg width="10" height="10" viewBox="0 0 10 10">
        <circle cx="5" cy="5" r="3.5" fill="none"
          stroke={tint || HRT.statusPartial} strokeWidth="1.5" opacity="0.45" />
        <path d="M 5 1.5 A 3.5 3.5 0 0 1 5 8.5" fill="none"
          stroke={tint || HRT.statusPartial} strokeWidth="1.5"
          strokeLinecap="round" />
      </svg>
    );
  }
  if (status === 'scheduled') {
    return (
      <div style={{
        width: 8, height: 8, borderRadius: 4,
        border: `1.5px solid ${tint || HRT.outline}`,
        boxSizing: 'border-box',
      }} />
    );
  }
  if (status === 'unplanned') {
    return (
      <div style={{
        width: 5, height: 5, borderRadius: 3,
        background: tint || HRT.outline,
      }} />
    );
  }
  if (status === 'future') {
    return <div style={{ width: 10, height: 2, borderRadius: 1, background: tint || HRT.outlineVariant, opacity: 0.5 }} />;
  }
  // none
  return <div style={{ width: 10, height: 2, borderRadius: 1, background: tint || HRT.outlineVariant }} />;
}

Object.assign(window, { MonthCalendar, DayStatusDot });
